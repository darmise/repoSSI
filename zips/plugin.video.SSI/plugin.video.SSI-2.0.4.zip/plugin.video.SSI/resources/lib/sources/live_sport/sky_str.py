# -*- coding: UTF-8 -*-
from os import link
from resources.lib.modules import  webutils, control, cache, linkSearch, constants
from resources.lib.modules.log_utils import log
import re
import requests
try:
	from urllib.parse import urlencode, urlparse
except:
	from urllib import urlencode, urlparse

class info():
	def __init__(self, url= ''):
		self.mode = 'sky_str'
		self.name = '[COLOR blue][B] Sky [/COLOR][COLOR red]Streaming [/B][/COLOR]'
		self.icon = "".join([urlparse(webutils.initSites("sky_str")).scheme, '://', urlparse(webutils.initSites("sky_str")).netloc, '/content/auto_site_logo.png'])
		self.enabled = control.setting("sky") == 'true'
		self.categorized = False
		self.paginated = False
		self.multilink = False

class main():
	
	def __init__(self):
		self.base = webutils.initSites("sky_str")
	
	def events(self):
		headers = {'User-Agent': constants.USER_AGENT, 'referer': self.base}
		html = requests.get(self.base, headers=headers).text
		#log('html %s' % html)
		events = re.findall(">\s+(.+?)\s+<a href=[\"\'](.+?)[\"\'] class='btn right'>", html)
		#events = tuple(list(dict.fromkeys(events)))
		#events = tuple(events)
		#log('Tupla: %s' % events)
		events = self.__prepare_events(events)
		#log('eventss: %s' % events)
		return events

	def __prepare_events(self, events):
		new = []
		#new.append(('','[COLOR lime][B] EVENTI DI GIORNATA [/B][/COLOR]', 'https://cdn.icon-icons.com/icons2/317/PNG/512/calendar-clock-icon_34472.png'))
		
		for e in events: 
			league = e[0]
			page = e[1]
			#log('page %s' % page)
			events2 = self.__prepare_page(page)
			url=''
			match =''
			image =''
			for ev in events2:
				url = ev[0]
				#log('url %s' % url)
				match = ev[1]
				#log('match %s' % match)
				image = ev[2]
				#log('image %s' % image)
			#url = e[0]
			#match = e[1]
			#image = e[2]
			#log("match: %s" % match)
				title = u'[COLOR yellow][B] %s [/B][/COLOR] [COLOR lime][%s][/COLOR]' % (match, league)
			#title = title.encode('utf-8')
				new.append((url,title, image))
		
		return new

	def __prepare_page(self, page):
		headers = {'User-Agent': constants.USER_AGENT, 'referer': page}
		html = requests.get(page, headers=headers).text
		index = html.find("div class='panel-heading'>Popular</div>")
		#log('html %s' % html)
		events2 = re.findall("<div class='mediathumb'>\s+<a href=[\"\'](.+?)[\"\'] title='(.+?)' class[\s\S]*?url[(](.+?)[)]", html[:index])
		#log('events2 %s' % events2)
		return events2

	def resolve(self,url):
		from resources.lib.modules import liveresolver
		d = liveresolver.Liveresolver().resolve(url)
		
		if d:
			if ".mpd" in d['url']:
				return d, False
			
			if "Referer=" in d['headers']:
				return '{}|{}'.format(d['url'], d['headers']), False
			return '{}|{}'.format(d['url'], urlencode(d['headers'])), False
		return ' '