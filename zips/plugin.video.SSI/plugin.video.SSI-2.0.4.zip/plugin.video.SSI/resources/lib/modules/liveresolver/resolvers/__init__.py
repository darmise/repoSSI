from os.path import dirname, basename, isfile, join
import glob
from resources.lib.modules.log_utils import log
import requests
modules = glob.glob(join(dirname(__file__), "*.py"))
__all__ = [ basename(f)[:-3] for f in modules if isfile(f) and not f.endswith('__init__.py')]

USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.141 Safari/537.36 OPR/73.0.3856.344'

'''
def check(name_resolver):
	sup = []
	for module in __all__:
		if module == name_resolver: 
			exec('from . import *')
			r = eval('{}.Resolver()'.format(module))
		#if r.isSupported(url, html):
		#	prio = 1
		#	try:
		#		prio = r.priority()
		#	except:
		#		pass

			sup.append(module)

	#sup.sort(key=lambda x:x[1])
	#sup = [x[0] for x in sup]
	return sup
'''

def resolve(name_resolver, url, referer = '', referer_map={}):
	#log('url resolve %s' % url)
	#log('referer resolve%s' % referer)
	try:
		html = requests.get(url,allow_redirects=True, timeout=3, headers={'referer':referer}).text
		#log('html %s' %html)
	except:
		return None

	#modules = check(name_resolver)
	#resolved = False
	#log('name : %s' % name_resolver)
	#log('referer : %s' % referer)
	#log('referer map : %s' % referer_map)
	
	for module in __all__:
		if module == name_resolver: 
			exec('from . import *')
			r = eval('{}.Resolver()'.format(module))
			if module == 'wigistream':
				#log('arrive in if')
				url_dict = r.resolve(url, html=html, referer=referer, referer_map=referer_map)
			else:
				url_dict = r.resolve(url, html=html, referer=referer)
			if url_dict:
				return url_dict
	return None
