import re
import requests
import json

try:
	from urllib.parse import urlparse
except:
	from urlparse import urlparse  # Python 2

from resources.lib.modules.log_utils import log
from resources.lib.modules import jsunpack
from resources.lib.modules.constants import USER_AGENT

class Resolver():

	def __init__(self):
		self.hosts = {}
		self.headers = {'User-Agent': USER_AGENT, 'Cache-control': 'no-cache'}

	#def priority(self):
	#	return 0

	#def isSupported(self, url, html):
	#	return bool(re.search('[\"\']((?:http)?[^\"\']+\.m3u8[^\"\']*)[\"\']', html))

	def resolve(self, url, html='', referer = None):
		#log(url)
		if 'm3u8' in url:
			play_url = url
			headers = {'Referer': referer+'/', 'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 'Host': urlparse(play_url).netloc, 'Origin': referer, 'Connection':'keep-alive'}
			return {'url': play_url, 'headers': headers}
		
		s = requests.session()
		s.headers.update(self.headers)
		if referer:
			s.headers.update({'Referer': referer})
		try:
			resp = s.get(url)
			#log(resp)
			try:
				url = resp.history[-1].url
			except:
				pass
			html = resp.text
			#log(html)
		
			play_url = re.findall('[\"\']((?:http)?[^\"\']+\.m3u8[^\"\']*)[\"\']', html)
			#log(play_url)
		except Exception as e:
			log(e)
			return None
		
		
		if len(play_url) == 0:
			return None
		
		if len(play_url[0]) > 60:
			play_url = re.findall('streamurl[\s\S]*?(ht(?:http)?[^\"\']+\.m3u8[quot^\"\']*)&', html)

		play_url = play_url[0]
		if play_url.startswith('%3C'):
			return None
		play_url = play_url.replace("\\", "")
		#log(play_url)
		if urlparse(play_url).scheme == '':
			play_url = play_url.replace('://', '')
			play_url = 'http://' + play_url
			play_url = play_url.replace('////','//')
		#log('url referer %s' % url)
		headers = {'Referer': url, 'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36', 'Host': urlparse(play_url).netloc, 'Origin': 'https://'+urlparse(url).netloc, 'Connection':'keep-alive'}
		#log("url: %s" % headers)
		return {'url': play_url, 'headers': headers}

