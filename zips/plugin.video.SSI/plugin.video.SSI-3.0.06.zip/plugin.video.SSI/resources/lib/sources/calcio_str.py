import re, xbmcgui

from datetime import datetime
from urllib.parse import urlparse
from resources.lib.modules import  webutils, connection, constants, liveresolver
from resources.lib.modules.log_utils import log

class Main():
    
    HEADERS = {
        "User-Agent": constants.USER_AGENT
    }
    
    def __init__(self):
        self.base = webutils.initSites('calcio_str_base')
        self.s = connection.Connession()
        self.s.session.headers.update(self.HEADERS)
        self.resolver = liveresolver.Liveresolver()
        
    def events(self):
        self.s.session.headers["Referer"] = self.base
        json_ = self.s.get(f"{self.base}api/events.php", timeout=5).json()

        oggi = datetime.now().date()

        return [
            (
                ev["streams"],
                f'[COLOR lime]({datetime.fromisoformat(ev["start_time"]).strftime("%H:%M")}) [/COLOR]'
                f'[COLOR yellow][B] {ev["home_team"]} - {ev["away_team"]} [/B][/COLOR]'
                f'- [{ev["league"]}]'
            )
            for ev in json_["events"]
            if datetime.fromisoformat(ev["start_time"]).date() == oggi
        ]

    def resolve(self,urls):
        urls = eval(urls)       
        index = xbmcgui.Dialog().select("Seleziona stream", [f'{u["label"]} {u["lang"]}' for u in urls])
         
        if index == -1:
            return None, False	
        
        d = self.resolver.resolve(urls[index]["url"])
        
        url = d["url"]
        headers = d["headers"]
        
        if ".mpd" in url:
            return d, False
            
        elif "Referer=" in headers:
            return f'{url}|{headers}', False
            
        header_string = "&".join(f"{k}={v}" for k,v in headers.items())
        return f'{url}|{header_string}', False
    
    
    