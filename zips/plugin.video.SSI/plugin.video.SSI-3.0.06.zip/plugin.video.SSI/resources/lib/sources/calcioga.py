import re

from urllib.parse import urljoin
from resources.lib.modules import  webutils, constants, liveresolver, connection
from resources.lib.modules.log_utils import log


class Main():
    
    HEADERS = {
        "User-Agent": constants.USER_AGENT
    }
 
    EVENTS_RE = re.compile(
        r'<li>\s+<div class="kode_ticket_text">\s+<h6>(.+?)</h6>\s+'
        r'<div class="ticket_title">\s+<h2>(.+?)</h2>\s+'
        r'<span>([^<]*)</span>\s+<h2>([^<]*)</h2>\s+</div>\s+'
        r'<p>(.+?)</p>\s+</div>\s+<div class="ticket_btn">\s+'
        r'<a href=[\"\'](.+?)[\"\']',
        re.DOTALL
    )
    
    def __init__(self):
        self.base = webutils.initSites("calcioga_base")
        self.s = connection.Connession()
        self.s.session.headers.update(self.HEADERS)
        self.resolver = liveresolver.Liveresolver()
    
    def events(self):
        self.s.session.headers["Referer"] = self.base
        html = self.s.get(self.base, timeout=5).text
        
        return [
            (urljoin(self.base, m.group(6)),
                f"({m.group(5)}) [COLOR yellow][B] {m.group(2)} {m.group(3)} {m.group(4)} [/B][/COLOR] - [{m.group(1)}]")
            for m in self.EVENTS_RE.finditer(html)
        ]

    def resolve(self,url):
        d = self.resolver.resolve(url)
        url = d["url"]
        headers = d["headers"]
        
        if ".mpd" in url:
            return d, False
            
        elif "Referer=" in headers:
            return f'{url}|{headers}', False
            
        header_string = "&".join(f"{k}={v}" for k,v in headers.items())
        return f'{url}|{header_string}', False
        
