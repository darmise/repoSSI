import re

from resources.lib.modules import  webutils, connection, constants, liveresolver, cache
from resources.lib.modules.log_utils import log

class Main():
    
    HEADERS = {
        "User-Agent": constants.USER_AGENT
    }
    
    EVENTS = re.compile('"t">(.+?)<\/span>[\s\S]*?<\/span> (.+?) <b>[\s\S]*?>(.+?)<\/([\s\S]*?)<\/span>\s+<\/span>')
    
    def __init__(self):
        self.base = webutils.initSites('roja_base')
        self.s = connection.Connession()
        self.resolver = liveresolver.Liveresolver()
    
    
    def _links(self, urls):
        links = re.findall('<tr>\s+<td>(.+?)<\/td>\s+<td>(.+?)<\/td>\s+<td>(.+?)<\/td>\s+<td>(.+?)<\/td>\s+<td>(.+?)<\/td>\s+<td>(.+?)<\/td>', urls)
        #log("links %s" % links)
        links = self.__prepare_links(links)
        return links
    
    def links(self, urls):
        return cache.get(self._links, 20, urls)
        
    def __prepare_links(self,links):
        links = links[1:]
        #log("links %s" % links)
        new=[]        
        count = 0
        for l in links:
            count = count + 1	
            name = l[1]
            lang = l[2]
            kbps = l[4]
            tempurl = l[5]
            url = re.findall('href=[\"\'](.+?)[\"\']', tempurl)[0]
            title = "%d - [COLOR yellow][B] %s [/B][/COLOR] (%s, %skbps)" % (count, name, lang, kbps)
            new.append((url,title, ""))
        return new
    
    def events(self):
        self.s.session.headers["Referer"] = self.base
        html = self.s.get(self.base).text
        
        return [       
            (ev[3],
            f"([COLOR lime][B]{ev[0]} [/COLOR][/B]) [COLOR yellow][B] {ev[2]} [/B][/COLOR] - [{ev[1]}]"
            )
            for ev in self.EVENTS.findall(html)
        ]
    
    def resolve(self,url):
        d = self.resolver.resolve(url)
        url = d["url"]
        headers = d["headers"]
                        
        if ".mpd" in url:
            return d, False
                            
        elif "Referer=" in headers:
            return f'{url}|{headers}', False
                            
        header_string = "&".join(f"{k}={v}" for k,v in headers.items())
        return f'{url}|{header_string}', False