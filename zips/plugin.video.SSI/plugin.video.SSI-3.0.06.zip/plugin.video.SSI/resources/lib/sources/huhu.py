import re

from urllib.parse import urljoin
from resources.lib.modules import  webutils, constants, liveresolver, connection
from resources.lib.modules.log_utils import log

class Main():
    
    HEADERS = {
        "User-Agent": constants.USER_AGENT
    }
    
    def __init__(self):
        self.base = webutils.initSites("huhu_base")
        self.s = connection.Connession()
        self.s.session.headers.update(self.HEADERS)
        self.resolver = liveresolver.Liveresolver()
    
    def events(self):
        json_object = self.s.post(f"{self.base}/mediaurl-catalog.json", json= {"language":"de","region":"DE","catalogId":"iptv","id":"","adult":False,"search":"","sort":"trending-region","filter":{"group":"Italy"},"cursor":None}, timeout=5).json()
        
        return [
            (
                item['url'],
                f"[COLOR yellow][B] {item['name']} [/B][/COLOR] "
            )
            for item in sorted(
                json_object['items'],
                key=lambda item: item['name'].casefold()
            )
        ]

    def resolve(self,url):
        json_object = self.s.post(f"{self.base}/mediaurl-resolve.json", json= {"language":"de","region":"DE","url":f"{url}"}).json()        
        
        d = self.resolver.resolve(json_object[0]['url'])
        url = d["url"]
        headers = d["headers"]
        
        if ".mpd" in url:
            return d, False
            
        elif "Referer=" in headers:
            return f'{url}|{headers}', False
            
        header_string = "&".join(f"{k}={v}" for k,v in headers.items())
        return f'{url}|{header_string}', False
  