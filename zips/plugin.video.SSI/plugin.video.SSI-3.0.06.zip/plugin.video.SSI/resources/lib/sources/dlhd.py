import re

from resources.lib.modules import  webutils, constants, connection, liveresolver
from resources.lib.modules.log_utils import log
import re, requests, xbmcgui
from urllib.parse import urlparse, urlencode

class Main():
    
    HEADERS = {
        "User-Agent": constants.USER_AGENT
    }
    
    EVENTS_RE = re.compile("href=[\"\'](.+?)[\"\']\s+data-title=[\"\'](.+?)italy")
    
    LINKS = re.compile("url=[\"\'](.+?)[\"\']")
    
    def __init__(self):
        self.base = webutils.initSites("dlhd_base")
        self.s = connection.Connession()
        self.s.session.headers.update(self.HEADERS)
        self.resolver = liveresolver.Liveresolver()

    def events(self):
        self.s.session.headers["Referer"] = self.base
        html = self.s.get(self.base, timeout = 5).text
        
        return [
            ("".join([urlparse(self.base).scheme, '://', urlparse(self.base).netloc, ev[0]]),
            f"[COLOR yellow][B] {ev[1]} [/B][/COLOR]")
            for ev in self.EVENTS_RE.findall(html) 
        ] 
        
    
    def resolve(self,url):
        ht = self.s.get(url).text
        players = self.LINKS.findall(ht)
        names = [f"Link {i}" for i in range(1, len(players)+1)]
        index = xbmcgui.Dialog().select("Seleziona stream", names)
        
        if index == -1:
            return None, False
        
        d = self.resolver.resolve(players[index])
        
        url = d["url"]
        headers = d["headers"]
                           
        if ".mpd" in url:
            return d, False
                               
        elif "Referer=" in headers:
            return f'{url}|{headers}', False
                               
        header_string = "&".join(f"{k}={v}" for k,v in headers.items())
        return f'{url}|{header_string}', False	
    
    