import re, xbmcgui

from urllib.parse import urljoin
from resources.lib.modules import  webutils, liveresolver, connection
from resources.lib.modules.log_utils import log


class Main():
    
    EVENT_RE = re.compile(
        r'<span class="category-label">'
        r'(?:<img\b[^>]*>\s*)?'
        r'(.+?)'
        r'</span>'
        r'([\s\S]*?)(?=<span class="category-label">|</main>)'
    )
    
    TIME = re.compile('>(?:<[^>]+>)*([^<]+)(?:<[^>]+>)*<\/span>')
    
    def __init__(self):
        self.base = webutils.initSites('hattrick_base')
        self.s = connection.Connession()
        self.resolver = liveresolver.Liveresolver()
        
    def events(self):
        html = self.s.get(self.base, timeout=5).text
        #log(html)
        return [
            (
                re.findall(
                    r'''<a href=["'](.+?)["']\s+target="_blank"\s+class="btn(?:\s+btn-(?:premium|720|1080))?">(.+?)(?:\s+ð.*?)?</a>''',
                    card
                ),
                f"([COLOR lime][B] {time}[/COLOR][/B])  [COLOR yellow] [B] {match} [/B][/COLOR] - [{ev[0]}]"
            )
            for ev in self.EVENT_RE.findall(html)
            for card in re.findall(
                r'<div class="match-card\b.*?(?=<div class="match-card\b|$)',
                ev[1],
                re.S
            )
            for match, time in zip(
                re.findall(
                    r'data-sq2="[^"]*">\s*(.+?)\s*<',
                    card
                ),
                self.TIME.findall(card)
            )
        ]
   
    def resolve(self,url):
        url = eval(url)
        index = xbmcgui.Dialog().select("Seleziona stream", [u[1] for u in url])
        
        if index == -1:
            return None, False
        
        link = self.base + url[index][0]
        
        d = self.resolver.resolve(link)
        
        url = d["url"]
        headers = d["headers"]
                
        if ".mpd" in url:
            return d, False
                    
        elif "Referer=" in headers:
            return f'{url}|{headers}', False
                    
        header_string = "&".join(f"{k}={v}" for k,v in headers.items())
        return f'{url}|{header_string}', False