import threading, base64, os, re, json, time, requests

from . import resolvers
from urllib.parse import urlparse, unquote, parse_qs
from resources.lib.modules.log_utils import log
from resources.lib.modules.constants import USER_AGENT
from resources.lib.modules import webutils, connection


class Liveresolver:
    
    FID_RE = re.compile(r'fid\s*=\s*["\']([^"\']+)["\']')
    STREAM_RE = re.compile('streamUrl:\s*[\'"](.+?)[\'"]')
    UNES_RE = re.compile(r'=\s*["\']([^"\']+)["\']+[^"\']+unescape')
    IFRAME_RE = re.compile(r'i?frame\s*.+?src=["\']?([^"\']+)',re.IGNORECASE | re.DOTALL)
    ATOB_RE = re.compile(r'(?:window\.atob\(["\'](.+?)["\']|canal\s*=\s*["\'](.+?)["\']|const b = [\'"](.+)[\'"])')
    JS_DOMAIN_RE = re.compile(r"text/javascript'\s+src=[\"\']([^\"\']+).js")
    

    def __init__(self, headers = None):
        if headers is None:
            headers = {"user-agent": USER_AGENT}
            
        self.headers = headers
        self.json_file = os.path.join(os.path.dirname(__file__), "json_data.json")	
        self.referer_map = {}
        self.player_referer = 'ezcaster'
        
    
    def resolve(self, url):
        resolved = []
  
        def worker():
            try:
                resolved.append(self.__resolve(url))
            except Exception:
                resolved.append(None)
                
        start = time.time()
        t = threading.Thread(target=worker, daemon=True)
        t.start()
        
        t.join(timeout=20)
        u = resolved[0]
        end = time.time()
        log(end-start)

        return u if resolved else None
    
    def __resolve(self, url):
        self.url = url

        self.referer_map[self.url] = ''
        
        log("url res %s " % url)
        
        iframes = self.__findIframes(self.url, links=[url])
        iframes = self.clearList(iframes, url)
        iframes = sorted(iframes, key=len, reverse=True)
        
        if not iframes: 
            iframes = [url]
        
        resolved = None
        
        data = webutils.accessJSON(os.path.join(os.path.dirname(__file__), 'json_data.json'))
        names = [el['name'] for el in data]
        
        for l in iframes:
            log(f" l: {l}")
            
            #Referer forzato da dirette
            if self.referer_map[l] == "":  
                self.referer_map[l] = self.url
            #index = iframes.index(l)
            #padre = urlparse(iframes[index +1] if index+1 < len(iframes) else None) #f"{parsed.scheme}://{parsed.netloc}/"

            
            if '&remote=' in l:
                u = l.replace("embed.html", "index.fmp4.m3u8").replace("&remote=None", "")
                resolved = resolvers.resolve('genericm3u8', u, referer=l)
                return resolved
            
            elif "extension://" in l:
                l2 = l.split("#")[1]
                if "m3u8" in l2:
                    if "headers" not in l2:
                        resolved = resolvers.resolve('genericm3u8', l2)
                        return resolved
                    
                    l2 = l2.split("&") 
                    u = l2[0]
                    code = l2[1].replace("headers=", "")
                    code += "=" * (-len(code) % 4)
                    decoded = eval(base64.b64decode(code).decode("utf-8"))
                    resolved = resolvers.resolve('genericm3u8', u, referer=decoded["referer"])
                    return resolved

                else:
                    l2 = l2.split("ck=")
                    
                    play_url = l2[0].rstrip("?").rstrip("&")
                    if len(l2) > 1:
                        code = l2[1]
                        if "=" not in code:
                            code += "=" * (-len(code) % 4)
                        clearkeys = base64.b64decode(code).decode("utf-8")
                        #log(clearkeys)
                        if "{" in clearkeys:
                            kid, key = list(json.loads(clearkeys).items())[0]
                            clearkeys = f"{kid}:{key}" 
                        clearkey = f'|{clearkeys}'
                        return {'url': play_url, 'clearkeys': clearkey}
                    
                    else: 
                        return {'url':play_url, 'clearkeys': ''}
                    

            for el in data:
                if el["name"] in l:
                    resolved = resolvers.resolve(el["resolve"], l, self.referer_map[l], self.referer_map[l])	
            
            if resolved is None:
                resolved = self.searchResolve(l, names)
            
            if resolved:
                break
        
        return resolved

    def searchResolve(self, l, names):
        resolves = ['genericm3u8', 'lovesomecommunity', 'api_m3u8', 'mpd_stream']#daddylive 'wigistream',
        for res in resolves:
            log(res)
            result = resolvers.resolve(res, l, self.referer_map[l],self.referer_map[l])
                    
            if result and l not in names:
                self.salvaJSON(self.normalize_url(l), res)
                return result
        return None
    
    def normalize_url(self, url):
        parsed = urlparse(url)

        host = parsed.netloc
        parts = host.split(".")

        if len(parts) >= 3:
            host = ".".join(parts[-2:])

        return host + parsed.path
    
    def salvaJSON(self, name, res):
        lista = webutils.accessJSON(self.json_file)
        lista.append({
                "name": name,
                "resolve": res
            })
        webutils.saveJSON(lista, self.json_file)
        return ""
    
    """"
    def __findpepper(self, url, txt):	
        if re.search("php\?ch=Canale\d{2}", url):
            n = int(url.split("?ch=")[-1].replace("Canale", "")) - 60
            #log(n)
            l_static = re.findall('return \s*[\'\"](.+?)[\'\"]\s*\+\s*\(parse', txt)[0]
            #log(l_static)
            return f"{l_static}{n}.php" 
        
        elif "php?ch=live" in url:
            n = url.split("?ch=")[-1].replace("live", "")
            map = eval(re.findall("const m\s*=\s*([\s\S]+?);", txt)[0])
            return map[n]
        
        elif "php?ch=" in url: #rivedere questo blocco
            token = None
            if url.lower().endswith("extra"):
                token = re.findall("TOKEN\s*=\s*[\'\"](.+?)[\'\"]", txt)[0]
                headers = re.findall("HEADERS\s*=\s*[\'\"](.+?)[\'\"]", txt)[0]
                resp_dic = eval(re.findall("_MAP\s*=\s*([\s\S]*?);", txt)[0])
            else:	
                resp_dic = eval(re.findall("JSON\s*=\s*([\s\S]*?);", txt)[0].replace('\\', ''))
                resp_dic = {re.sub(r'[^a-z0-9]', '', k.lower()): v for k, v in resp_dic.items()}
                        
            ch = url.split("?ch=")[-1].lower()
            #log(ch)
            link = resp_dic[ch]
            extend = re.findall('[\'\"](.+?)#[\'\"]', txt)[0]
            if token:
                l = re.findall("#(.+?)\/\$", txt)[0]
                link = "".join([l, "/", link, "/index.m3u8?token=", token, "&headers=", headers])
            return f"{extend}#{link}"

        return ""
    """        
    def __findIframes(self, url, links, checked = None): #links mai None
        if checked is None:
            checked = set()
            
        if self.player_referer in url: #problem connection: want referer
            base = urlparse(webutils.initSites("calcioga_base"))
            self.referer_map[url] = f"{base.scheme}://{base.netloc}"
            
        stack = [url]
        while stack:
            current_url = stack.pop()
            
            try:
                s = connection.Connession()
                s.session.headers.update({'User-Agent': USER_AGENT, 'referer': self.referer_map.get(current_url, ""), 'sec-fetch-dest': 'iframe'})
                r = s.get(current_url, allow_redirects=True, timeout=10)
                #log(r.text)
            except Exception as e:
                log(f'Liveresolver Error:{current_url}: {e}')
                continue
            
            """
            #----------------- PepperLive code ---------------------
            pepper_check = re.findall("const E([\s\S]*)<\/s", r.text)
            if pepper_check:
                link = self.__findpepper(url, pepper_check[0])
                
                if link and link not in checked:
                    checked.add(link)
                    self.referer_map[link] = url
                    
                    if "extension://" not in link:
                        stack.append(link)
                
                continue
            #-------------------------------------------------------
        """
            if r.status_code != 200:
                continue
            
            parsed = urlparse(current_url)
            
            base_netloc = parsed.netloc
            base_path = parsed.path.rsplit("/", 1)[0].strip("/")
            
            urls = re.findall('i?frame\s*.+?src=[\"\']?([^\"\']+)', r.text, flags=re.IGNORECASE)
            
            api = re.findall("(?:>\s+)?fetch\([\"\'](.+?)[\"\']", r.text)
            api = self.clearList(api, None)
            
            if api:
                url_api = "".join(['https://', urlparse(current_url).netloc, '/', api[0]]) #MANCA ID
                
                if url_api.endswith("="):
                    id = current_url.split("=")[1]
                    url_api = "".join([url_api, id])
                u = s.get(url_api).json().get("url")
                
                if u:
                    urls.append(u)
            urls = self.__customUrls(r.text, current_url, urls)
            urls = self.clearList(urls, current_url)
            checked.add(current_url)
            
            if not urls:
                break 
            
            for u in urls:
                if not u:
                    continue
                
                if "\\" in u:
                    u = u.replace("\\", "")
                   
                parsed_u = urlparse(u)
                
                if not parsed_u.netloc:
                    
                    if u.startswith('/'):	
                        u = f'http://{base_netloc}{u}'
                    else:
                        u = f'http://{base_netloc}/{base_path}/{u.lstrip("/")}'
                
                elif not parsed_u.scheme:
                    u = 'http://' + u.lstrip('/')
    
                u = u.strip()
                
                if u not in checked:
                    stack.append(u)
                    links.append(u)
                    self.referer_map[u] = current_url
                
        return links 
    
            
    def __customUrls(self, r, ref, urls): 
        parsed = urlparse(ref)
        params = parse_qs(parsed.query)
        if "id" in params:
            id_value = params.get("id", [""])[0]
            try: 
                padded = id_value + "=" * (-len(id_value) % 4)
                decoded = base64.b64decode(
                    padded, altchars=b"-_", validate=True
                ).decode("utf-8")
                decoded_parsed = urlparse(decoded)
                if decoded_parsed.scheme in ("http", "https") and decoded_parsed.netloc:
                    urls.append(decoded)
            except (ValueError, UnicodeDecodeError):
                pass
                       
        fid = self.FID_RE.search(r) 
        if fid:
            domain = self.JS_DOMAIN_RE.search(r)
            
            if domain:
                u = ''.join(["https:", domain[0], ".php?player=desktop&live=", fid[0]])
                urls.append(u)
                
        s = self.STREAM_RE.search(r)
        if s:
            urls.append(s.group(1))

        atob = self.ATOB_RE.search(r)
        if atob:
            encoded = atob.group(1) or atob.group(2) or atob.group(3)
            try:
                u = base64.b64decode(encoded).decode('utf-8')
                urls.append(u)
            except Exception:
                pass
            
        unes = self.UNES_RE.search(r)
        if unes:
            try:
                html = unquote(unes.group(1).replace("@", "%"))
                
                iframe = self.IFRAME_RE.search(html)
                
                if iframe:
                    u = iframe.group(1)
                    urls.append(u)
                    self.referer_map[u] = ref
            except Exception:
                pass
        for u in self.IFRAME_RE.findall(r):
            if u not in urls:
                urls.append(u)
        return urls
        
    def clearList(self, iframe_list, link):
        blacklist = (',', 'adserv', 'javascript', ';', 'ads.com', '.js', '.png', '.gif', '.webp',
                'ad4', '()', '.svg', '/https', 'soccer.store', '/\\', "sportsonline", "sportzonline", 
                "premiumtv/t", self.player_referer, "//superiorcrop", "redirect", 'about:blank')
        cleared = []

        for s in iframe_list:
            if not any(b in s for b in blacklist):
                cleared.append(s)

        if link is not None and not link.endswith(".m3u8") and link in cleared:
            cleared.remove(link)
        return cleared
    
    
       