import re
from urllib.parse import urlparse
from resources.lib.modules.log_utils import log
from resources.lib.modules import constants, connection

class Resolver():

    def __init__(self):
        self.headers = {'User-Agent': constants.USER_AGENT}
        self.BASE_API = "https://api.screenify.shop/api"
        self.s = connection.Connession()
        
    def resolve(self, url, html='', referer=None):
        try:
            if "?config" not in url:
                raise ValueError("?config non trovato")
        except ValueError:
            return None
        try:
            config = url.split("?config=")[-1]
            url_api = f"{self.BASE_API}/embed-configs/public/{config}"
            
            self.s.session.headers.update(self.headers)
            if referer:
                self.s.session.headers.update({'Referer': referer})
            
            resp_api = self.s.get(url_api).json()
            #log(resp_api)
        
        except:
            return None

        stream_id = resp_api.get("stream")
        active = resp_api.get("isActive")
        relays, token = self.get_relays(url)
        
        urls = [f"{relay}/stream/{stream_id}/index.m3u8?token={token}" for relay in relays]
        play_url = next((u for u in urls if active), None)
        #log(play_url)
        headers = {'Referer': 'https://'+urlparse(url).netloc+'/', 'Origin': 'https://'+urlparse(url).netloc, "User-Agent": self.AGENT}    
        return {'url': play_url, 'headers': headers}
    
    def get_relays(self, url):
        #s = webutils.Connession()
        r = self.s.get(url).text
        u = "\/_next\/static\/chunks\/app\/embed\/player"
        code = re.findall(f"{u}(.+?).js", r)[0]
        url_js = "".join(['https://', urlparse(url).netloc, u.replace("\\", ""), code, ".js"])
        html = self.s.get(url_js).text
        #log(html)
        relays = re.findall("_URL\|*\|*[\'\"](.+?)[\'\"]", html)
        token = re.findall("_TOKEN\|*\|*[\'\"](.+?)[\'\"]", html)[0]
        return relays, token     
