import ast
import hashlib
import sqlite3
import time

from resources.lib.modules import control
from resources.lib.modules.log_utils import log


def _funcion_name(function):
    try:
        return f"{function.__module__}.{function.__qualname__}"
    except:
        return str(function)

def _make_hash(args):
    md5 = hashlib.md5()
    
    for arg in args:
        md5.update(str(arg).encode("utf-8"))
        
    return md5.hexdigest()

def _connect():
    control.makeFile(control.dataPath)
    return sqlite3.connect(control.cacheFile)

def remove(function, *args):

    func = _funcion_name(function)
    key = _make_hash(args)
    
    try:
        db = _connect()
        cur = db.cursor()
        cur.execute(
            "DELETE FROM rel_list WHERE func=? AND args=?",
            (func, key)
        )
        
        db.commit()
        db.close()
    except Exception as e: 
        log(f"cache remove error: {e}")
    

def get(function, timeout, *args, **kwargs):
    table = kwargs.get("table", "rel_list")
    func = _funcion_name(function)
    key = _make_hash(args)
    
    response = None
    
    try:
        db = _connect()
        cur = db.cursor()
        cur.execute(
            f"""
            CREATE TABLE IF NOT EXISTS {table}
            (
                func TEXT,
                args TEXT,
                response TEXT,
                added TEXT,
                UNIQUE(func,args)
            )
            """
        )
        
        cur.execute(
            f"SELECT response, added FROM {table} WHERE func=? AND args=?",
            (func, key)
        )
        
        row = cur.fetchone()
        
        if row:
            response = ast.literal_eval(row[0])
            
            age = (int(time.time()) - int(row[1])) / 60

            if age < int(timeout):
                db.close()
                return response
    except Exception as e:
        log(f"cache read error: {e}")
    
    try:
        result = function(*args)
        
        if result in (None, []) and response is not None:
            return response
        
    except Exception as e:
        log(f"cache function error: {e}")
        return response
    
    try:
        cur.execute(
            f"DELETE FROM {table} WHERE func=? AND args=?",
            (func, key)
        )
        
        cur.execute(
            f"INSERT INTO {table} VALUES (?, ?, ?, ?)",
            (
                func,
                key,
                repr(result),
                int(time.time())
            )
        )
        
        db.commit()
        db.close()
    except Exception as e: 
        log(f"cache write error: {e}")
        
    return result


def clear(table=None):
    try:
        control.idle()

        if table is None: 
            table = ['rel_list', 'rel_lib']
            
        elif not isinstance(table, list):
            table = [table]

        if not control.yesnoDialog('Sei sicuro?', '', ''):
            return 
        
        db = _connect()
        cur = db.cursor()

        for t in table:
            cur.execute(f"DROP TABLE IF EXISTS {t}")
            
        db.commit()
        db.execute("VACUUM")
        db.close()
        
        control.infoDialog("Cache pulita!")
        
    except Exception as e:
        log(f"cache clear error: {e}")

