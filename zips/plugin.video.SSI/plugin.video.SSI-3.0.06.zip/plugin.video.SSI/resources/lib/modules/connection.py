import requests

class Connession:
    _session = None

    def __init__(self):
        if Connession._session is None:
            Connession._session = requests.Session()

    @property
    def session(self):
        return Connession._session

    def get(self, url, **kwargs):
        return self.session.get(url, **kwargs)

    def post(self, url, **kwargs):
        return self.session.post(url, **kwargs)    