import re
import requests

from urllib.parse import urlparse, quote_plus

from resources.lib.modules.log_utils import log
from resources.lib.modules.constants import USER_AGENT

from resources.lib.modules import webutils

class Resolver():

	def __init__(self):
		self.AGENT = USER_AGENT
		self.headers = {'User-Agent': self.AGENT, 'Cache-control': 'no-cache'}

	def resolve(self, url, html='', referer = None):
		s = requests.session()
		s.headers.update(self.headers)
		if referer:
			s.headers.update({'Referer': referer})
		log(url)
		return