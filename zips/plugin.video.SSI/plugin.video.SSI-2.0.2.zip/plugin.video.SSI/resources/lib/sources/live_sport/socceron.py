# -*- coding: UTF-8 -*-
from os import link
from resources.lib.modules import  webutils, control, cache, linkSearch, constants
from resources.lib.modules.log_utils import log
import re
import requests, xbmcgui
try:
	from urllib.parse import urlencode
except:
	from urllib import urlencode

class info():
	def __init__(self, url= ''):
		self.mode = 'socceron'
		self.name = '[COLOR white][B] Rabona [/B][/COLOR]'
		self.icon = 'https://rabona.name/log3.png'
		self.enabled = control.setting("socc") == 'true'
		#self.enabled = True
		self.categorized = False
		self.paginated = False
		self.multilink = False

class main():
	
	def __init__(self):
		self.base = control.setting('socceron_base')
	
	def events(self):
		#from datetime import timedelta, date
		#oggi = date.today().strftime("%d")
		#domani = (date.today() + timedelta(days=1)).strftime("%d")
		
		headers = {'User-Agent': constants.USER_AGENT, 'referer': self.base}
		result = requests.get(self.base, headers=headers).text
		#log("html %s" % result)
		#index = result.find("Programma " + oggi)
		#index2 = result.find("Programma " + domani)
		#result2 = result[index:index2]

		events = re.findall(';<img src=[\"\'](.+?)[\"\'] [\s\S]*?&nbsp;(.+?)<\/span>([\s\S]*?)<\/td>', result)
		#log("events %s" % events)
		events = self.__prepare_events(events)
		return events

	def __prepare_events(self,events):
		new = []
		for ev in events: 
			icon = ev[0]
			#log("icon %s" % icon)
			league = ev[1]
			#log("icon %s" % match)
			
			urlstemp = re.findall('href=[\"\'](.+?)[\"\'] target="_blank"[\s\S]*?>(.+?)<\/a>', ev[2])
			#urls = self.__prepare_url(urltemp)	
			#log('urls %s' % url)
			
			title = '[COLOR yellow][B] %s [/B][/COLOR]' % league
			
			new.append((urlstemp,title, icon))	
			
		return new

	def resolve(self, urlstemp):
		from resources.lib.modules import liveresolver
		
		dialog = xbmcgui.Dialog()
		streamstemp = urlstemp[1:-1]
		streams = list(streamstemp.split(','))
		#log('test stream %s' % streams)
	
		lst = [streams[i][2:-2] for i in range(1, len(streams), 2)]
		name = ['Link %s' % t for t in range(1, (len(lst)+1))]
		streams2 = [streams[y][2:-1] for y in range(0, len(streams), 2)]
		#log('streams2 %s ' % streams2)
		index = dialog.select("Seleziona stream", name)
		#log('indice %s' % index)
		urltemp = ""
		url = ""
		if index != -1:
			if index == 0:
				urltemp = streams2[index]
				#log("urltemp %s" % urltemp)
				url = self.__prepare_url(urltemp)
				url = self.__check_url(url)
				#log("url rabona %s" % url)

			else:	
				urltemp = streams2[index][1:]
				#log("urltemp %s" % urltemp)
				url = self.__prepare_url(urltemp)
				url = self.__check_url(url)
		
		#log("url %s" % url)
		d = liveresolver.Liveresolver().resolve(url)
		if d:
			#if d['url'].startswith('plugin://'):
			#	return d['url']
			return '{}|{}'.format(d['url'], urlencode(d['headers'])), False
		return url, True

	def __prepare_url(self, urltemp):
			try:
				html = requests.get(urltemp, timeout=2).text
			except:
				pass
			#log("html %s" % html)
			ursltemp2 = re.findall("src=[\"\'](.+?)[\"\']", html)
			#log("links %s" % ursltemp2)
			for link in constants.socceron:
				for urltemp2 in ursltemp2:
					if link in urltemp2:
						#log("url utile %s " % urltemp2)
						url = urltemp2
				
			return url	
	
	def __check_url(self, url):
		if url.startswith('//'):
			url = 'https:' + url
		return url

