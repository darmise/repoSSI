import re
import requests
import base64
import json

try:
	from urllib.parse import urlparse
except:
	from urlparse import urlparse  # Python 2

from resources.lib.modules.log_utils import log
from resources.lib.modules import jsunpack
from resources.lib.modules.constants import USER_AGENT, dic_telerium


class Resolver():

	def __init__(self):
		self.hosts = {}
		self.headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36', 'Cache-control': 'no-cache'}

	def resolve(self, url, html='', referer = None):
    	
		referer = 'https://'+ urlparse(url).netloc
		#change url
		parsed = (urlparse(url).query).split('?id=')  
		code = parsed[0]
		id = parsed[1] 
		if code in dic_telerium.keys():
			url = dic_telerium[code] + id + '.php'
			log(url)
		referer = 'https://'+ urlparse(url).netloc + '/'
		
		s = requests.session()
		s.headers.update({'Referer': referer})
		
		resp = s.get(url, timeout=3).text
		
		try:
			fid = re.findall("fid=[\"\'](.+?)[\"\']", resp)[0]
			
			url = 'https://vodkapr3mium.com/deportivo.php?player=desktop&live=' + fid

			
			s.headers.update({'Referer': referer})
			
			res = s.get(url, timeout=2).text
			
			lettera = re.findall('[\"\'](.+?)[\"\']].join', res)
			play_url = lettera[0].replace('"', '').replace(',', '').replace("https:\/\/\/\/", "https://").replace('\/hls\/', '/hls/')
			headers = {'Referer': 'https://' + urlparse(url).netloc, 'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', 'Origin': 'https://' + urlparse(url).netloc, 'Connection':'keep-alive'}
			return {'url': play_url, 'headers': headers}
		except:
			return None
