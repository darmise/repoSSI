# -*- coding: UTF-8 -*-
from os import link
from resources.lib.modules import  webutils, control, constants
from resources.lib.modules.log_utils import log
import re, os, json
import requests
try:
	from urllib.parse import urlencode, urlparse
except:
	from urllib import urlencode, urlparse

class info():
	def __init__(self, url= ''):
		self.mode = 'mpd_streams'
		self.name = '[COLOR yellow][B] Flussi MPD [/B][/COLOR]'
		self.icon = 'https://static.vecteezy.com/ti/vettori-gratis/p1/5093329-il-piu-popolare-sport-illustrazione-vettore-gratuito-vettoriale.jpg'
		#self.enabled = control.setting("mpd") == 'true'
		self.enabled = False
		self.categorized = False
		self.paginated = False
		self.multilink = False

class main():
	
	def events(self):
		json_list = webutils.accessJSON(os.path.join(os.path.dirname(__file__), 'mpd_list.json'))
		events = self.__prepare_events(json_list)
		return events

	def __prepare_events(self, json_list):
		new = []

		for json in json_list:
			channel = json['channel']
			url = json['url']
			title = '[COLOR lime][B] %s [/B][/COLOR]'% (channel)
			new.append((url, title))
		return new

	def resolve(self, url):
		json_list = webutils.accessJSON(os.path.join(os.path.dirname(__file__), 'mpd_list.json'))
		for json in json_list:
			
			
			if json['url'] == url:
				k1 = json['k1']
				k2 = json['k2']
				urls = {
						"url": url,
						"clearkeys": "".join(['|',k1,':',k2])
				}
				
		if urls:
			if ".mpd" in urls['url']:
				return urls, False
		return ' '