# -*- coding: UTF-8 -*-
from os import link
from resources.lib.modules import  webutils, control, cache, linkSearch, constants
from resources.lib.modules.log_utils import log
import re, xbmcgui
import requests
try:
	from urllib.parse import urlencode
except:
	from urllib import urlencode

class info():
	def __init__(self, url= ''):
		self.mode = 'starlive'
		self.name = '[COLOR aqua][B] Nopay [/B][/COLOR]'
		self.icon = 'https://iconape.com/wp-content/png_logo_vector/serie-a-logo-2020.png'
		self.enabled = control.setting("nop") == 'true'
		#self.enabled = True
		self.categorized = False
		self.paginated = False
		self.multilink = False

class main():
	
	def __init__(self):
		self.base = control.setting('starlive_base')

	def events(self):
		from datetime import timedelta, date
		#d0 = date.today()
		#d1 = d0.strftime("%d/%m/%Y")
		#d2 = date.today() + timedelta(days=1)
		#d3 = d2.strftime("%d/%m/%Y")
		headers = {'User-Agent': constants.USER_AGENT, 'referer': self.base}
		html_full = requests.post(self.base, {'password': control.setting('pass_nopay')}, headers=headers).text
		#log("html full %s" % html_full)
		#html_full = requests.get(self.base, headers=headers).text
		#index1 = html_full.find(d1)
		#log('index1 %s' % index1)
		#index2 = html_full.find(d3)
		#html_partial = html_full[index1:index2]#19052-20637
		#events = re.findall('">\s+(.+?)<br>([\s\S]*?)\s+<\/div>[\s\S]*?> LINK SD <\/h5>([\s\S]*?)<\/div>\s+<div', html_full)
		events = re.findall('<b>(.+?)<\/b> <a href=[\"\'](.+?)[\"\'][\s\S]*? flag-(.+?)"[\s\S]*?i>(.+?)<\/a>', html_full)
		#log('even: %s' % events)
		events = self.__prepare_events(events)
		#log('eventss: %s' % events)
		return events

	def __prepare_events(self, events):
		new = []
		new.append(('','[COLOR lime][B] EVENTI DI GIORNATA [/B][/COLOR]', 'https://cdn.icon-icons.com/icons2/317/PNG/512/calendar-clock-icon_34472.png'))
		
		for ev in events: 
			league = ev[0]
			url = self.base + ev[1]
			nation = ev[2]
			channel = ev[3]
		
			title = '[COLOR yellow][B] %s [/B][/COLOR] - [COLOR lime] %s[/COLOR] (%s)'%(league, channel, nation)	
			#log('nez: %s' % title)	
			new.append((url, title))
		return new
	
	def resolve(self,url):
		from resources.lib.modules import liveresolver
		
		d = liveresolver.Liveresolver().resolve(url)
		if d:
			#if d['url'].startswith('plugin://'):
			#	return d['url']
			return '{}|{}'.format(d['url'], urlencode(d['headers'])), False
		return url, True
		