# -*- coding: UTF-8 -*-
from os import link
from resources.lib.modules import  webutils, control, constants
from resources.lib.modules.log_utils import log
import re, requests, xbmcgui
from urllib.parse import urlparse, urlencode

class info():
	def __init__(self, url = ''):
		self.mode = 'dlhd'
		self.name = '[COLOR white][B] DaddyLive[/B][/COLOR] [COLOR blue][B]HD [/B][/COLOR] - [COLOR white](Channel)[/COLOR]'
		self.icon = 'https://seo-michael.co.uk/content/images/size/w1500h600/2023/05/dlpi.jpg'
		self.enabled = control.setting("daddy_ch") == 'true'
		#self.enabled = True
		self.categorized = False
		self.paginated = False
		self.multilink = False

class main():
	
	def __init__(self):
		self.base = webutils.initSites("daddy_ch_base")

	def events(self):
		headers = {'User-Agent': constants.USER_AGENT, 'referer': self.base}
		html = requests.get(self.base, headers=headers).text
		#log(html)
		events = re.findall('href=[\"\'](.+?)[\"\']\s+data-title=[\"\'](.+?)italy', html)
		#log(events) 
		events = self.__prepare_events(events)
		return events

    
	def __prepare_events(self, events):
		new = []

		for ev in events: 
			channel = ev[1]
			url = urlparse(self.base).scheme + '://'+ urlparse(self.base).netloc + ev[0]
			#url = url.replace("stream/", "cast/")
			title = '[COLOR yellow][B] %s [/B][/COLOR] ' % channel	
			new.append((url, title))
		return new
	
	def resolve(self,url):
		from resources.lib.modules import liveresolver
		
		ht = requests.get(url).text
		players = re.findall("url=[\"\'](.+?)[\"\']", ht)
		dialog = xbmcgui.Dialog()
		names = [f"Link {i}" for i in range(1, len(players)+1)]
		index = dialog.select("Seleziona stream", names)
		
		if index != -1:
			u = players[index]
		
		d = liveresolver.Liveresolver().resolve(u)
		if d:
			if ".mpd" in d['url']:
				return d, False
			
			if "Referer=" in d['headers']:
				return '{}|{}'.format(d['url'], d['headers']), False
			return '{}|{}'.format(d['url'], urlencode(d['headers'])), False
		return ' '	