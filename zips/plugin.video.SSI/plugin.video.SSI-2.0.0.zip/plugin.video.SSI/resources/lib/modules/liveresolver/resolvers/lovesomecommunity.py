import re
import requests
import json

try:
	from urllib.parse import quote, urlparse
except:
	from urlparse import urlparse, quote  # Python 2

from resources.lib.modules.log_utils import log
from resources.lib.modules import jsunpack, webutils
from resources.lib.modules.constants import USER_AGENT


class Resolver():

	def __init__(self):
		self.hosts = {}
		self.headers = {'User-Agent': USER_AGENT, 'Cache-control': 'no-cache'}

	def resolve(self, url, html='', referer = None):
		s = requests.session()
		s.headers.update(self.headers)
		if referer:
			s.headers.update({'Referer': referer})
		
		try:
			res = s.get(url, timeout=5).text
			lettera = re.findall('[\"\'](.+?)[\"\']].join', res)
			play_url = lettera[0].replace('"', '').replace(',', '').replace("https:\/\/\/\/", "https://").replace('\/hls\/', '/hls/')
			headers = {'Referer': 'https://' + urlparse(url).netloc, 'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', 'Origin': 'https://' + urlparse(url).netloc, 'Connection':'keep-alive'}
			return {'url': play_url, 'headers': headers}
		except:
			return None