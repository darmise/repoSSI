import re
import requests
import json

try:
	from urllib.parse import quote, urlparse, quote_plus
except:
	from urlparse import urlparse, quote, quote_plus  # Python 2

from resources.lib.modules.log_utils import log
from resources.lib.modules import jsunpack, webutils
from resources.lib.modules.constants import USER_AGENT


class Resolver():

	def __init__(self):
		self.hosts = {}
		self.headers = {'User-Agent': USER_AGENT, 'Cache-control': 'no-cache'}

	def resolve(self, url, html='', referer = None):
		s = requests.session()
		s.headers.update(self.headers)
		if referer:
			s.headers.update({'Referer': referer})
		try:
			resp = s.get(url)
			try:
				url = resp.history[-1].url
			except:
				pass
			html = resp.text
			#log(html)
		except Exception as e:
			log(e)
			return None
		
		try:
			play_url = re.findall('[\"\']((?:http)?[^\"\']+\.mpd[^\"\']*)[\"\']', html)
			
			if len(play_url) == 0:
				return None
			
			play_url = play_url[0]
			#log(play_url)
			clearkeys = re.findall('[\"\'](.+?)[\"\']\s*:\s*[\"\'](.+?)[\"\']', html)
			clearkey = f'|{clearkeys[0][0]}:{clearkeys[0][1]}'
			#log(clearkey)
			return {'url': play_url, 'clearkeys': clearkey}
		except:
			pass