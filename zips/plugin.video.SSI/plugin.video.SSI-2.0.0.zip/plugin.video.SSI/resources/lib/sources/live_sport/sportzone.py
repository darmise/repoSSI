# -*- coding: utf-8 -*-
from os import link
from resources.lib.modules import  webutils, control, cache, linkSearch, constants
from resources.lib.modules.log_utils import log
import re
import requests
try:
	from urllib.parse import urlparse, quote_plus, urlencode
except:
	from urllib import quote_plus, urlencode

class info():
	def __init__(self):
		self.mode = 'sportzone'
		self.name = '[COLOR orange][B] Sportzone [/COLOR][/B]'
		self.icon = "".join([urlparse(webutils.initSites("sportzone_base")).scheme, '://', urlparse(webutils.initSites("sportzone_base")).netloc, "//images/66a4c20689dbe.png"])
		self.enabled = control.setting("sportz") == 'true'
		self.categorized = True
		self.paginated = False
		self.multilink = False

class main():
	def __init__(self, url = ''):
		self.base = webutils.initSites("sportzone_base")

	def categories(self):
		self.html1 = self.base + 'category/Calcio'
		self.html2 = self.base + 'category/Formula%201'
		self.html3 = self.base + 'category/MotoGP'
		self.html4 = self.base + 'category/Tennis'
		cats = self.__prepare_cats()
		return cats

	def events(self,url):
		headers = {'User-Agent': constants.USER_AGENT, 'referer': url}
		html = requests.get(url, headers=headers).text
		index1 = html.find('>Domani</button>')
		html = html[index1:]
		events = re.findall('<a hr([\s\S]*?)an>\s+', html)
		#log(events)
		events = self.__prepare_events(events)
		return events
	
	def __prepare_cats(self):
		new = []
		new.append((self.html1,'[COLOR orange][B] Calcio [/COLOR][/B]','icons/calcio.png'))
		new.append((self.html2,'[COLOR orange][B] Formula 1 [/COLOR][/B]','icons/formula1.png'))
		new.append((self.html3,'[COLOR orange][B] MotoGP [/COLOR][/B]','icons/motogp.png'))
		new.append((self.html4,'[COLOR orange][B] Tennis [/COLOR][/B]','icons/tennis.png'))
		return new

	def __prepare_events(self,events):
		new=[]
		for e in events:
			url = re.findall('\/event\/(.+?)[\"\'] style', e)[0]
			url = webutils.initSites("sportzone_base") + "event/" + url
			event = re.findall('cat_item">\s+(.+?)\s+<\/sp', e) [0]
			title = '[COLOR yellow][B]%s[/B][/COLOR]' % (event)        
			new.append((url, title))
		return new

	def resolve(self,url):
		from resources.lib.modules import liveresolver
		d = liveresolver.Liveresolver().resolve(url)
		#log('controllo d %s' % d)
		if d:
			if ".mpd" in d['url']:
				return d, False
			
			if "Referer=" in d['headers']:
				return '{}|{}'.format(d['url'], d['headers']), False
			return '{}|{}'.format(d['url'], urlencode(d['headers'])), False
		return ' '

