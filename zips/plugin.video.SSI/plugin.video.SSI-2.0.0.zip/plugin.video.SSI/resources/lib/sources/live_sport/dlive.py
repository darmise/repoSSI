# -*- coding: UTF-8 -*-
from os import link
from resources.lib.modules import  webutils, control, cache, linkSearch, constants
from resources.lib.modules.log_utils import log
import re, xbmcgui
import requests, json
try:
	from urllib.parse import urlencode
except:
	from urllib import urlencode
try:
	from urllib.parse import urlparse
except:
	from urlparse import urlparse  # Python 2

class info():
	def __init__(self, url= ''):
		self.mode = 'dlive'
		self.name = '[COLOR white][B] DaddyLive[/B][/COLOR] [COLOR blue][B]HD [/B][/COLOR] - [COLOR white](Events)[/COLOR]'
		self.icon = 'https://seo-michael.co.uk/content/images/size/w1500h600/2023/05/dlpi.jpg'
		#self.enabled = control.setting("dlive") == 'true'
		self.enabled = False
		self.categorized = False
		self.paginated = False
		self.multilink = False

class main():
	
	def __init__(self):
		self.base = webutils.initSites('dlive_base')

	def events(self):
		headers = {'User-Agent': constants.USER_AGENT, 'referer': self.base}
		dict_data = requests.get(self.base, headers=headers).json()
		events = self.__prepare_events(dict_data)
		return events

	def __prepare_events(self, dict_data):
		new = []
		for key in dict_data:
			cat = dict_data[key] #cat 
			for cat in dict_data[key]:
				events = list(dict_data[key][cat])
				for i in range(0, len(events)):
					evento = events[i]["event"]
					channels = events[i]["channels"]
					for y in range(0, len(channels)):
						name = channels[y]["channel_name"]
						id = channels[y]["channel_id"]
						url = 'https://'+ urlparse(self.base).netloc + "/stream/stream-" + id + ".php"
						
						title = '[COLOR yellow][B] %s [/B][/COLOR] (%s)'%(evento, name)		
						new.append((url, title))
		return new
	
	def resolve(self,url):
		from resources.lib.modules import liveresolver
		
		d = liveresolver.Liveresolver().resolve(url)
		if d:
			return '{}|{}'.format(d['url'], d['headers']), False
		return url, True
		