# -*- coding: UTF-8 -*-
from os import link
from resources.lib.modules import  webutils, control, cache, linkSearch, constants
from resources.lib.modules.log_utils import log
import re, xbmcgui
import requests
try:
	from urllib.parse import urlencode, urlparse
except:
	from urllib import urlencode, urlparse

class info():
	def __init__(self, url= ''):
		self.mode = 'calcioga'
		self.name = '[COLOR lime][B] Calcio.ga [/B] [/COLOR]'
		self.icon = "".join([urlparse(webutils.initSites("calcioga_base")).scheme, '://', urlparse(webutils.initSites("calcioga_base")).netloc, '/images/logo.png'])
		self.enabled = control.setting("calga") == 'true'
		self.categorized = False
		self.paginated = False
		self.multilink = False

class main():
	
	def __init__(self):
		self.base = webutils.initSites("calcioga_base")
	
	def events(self):
		headers = {'User-Agent': constants.USER_AGENT, 'referer': self.base}
		html = requests.get(self.base, headers=headers).text
		events = re.findall('<li>\s+<div class="kode_ticket_text">\s+<h6>(.+?)</h6>\s+<div class="ticket_title">\s+<h2>(.+?)</h2>\s+<span>VS</span>\s+<h2>(.+?)</h2>\s+</div>\s+<p>(.+?)</p>\s+</div>\s+<div class="ticket_btn">\s+<a href=[\"\'](.+?)[\"\']>', html)
		#log('ERR: %s' % events)
		events = tuple(events)
		events = self.__prepare_events(events)
		#log('eventss: %s' % events)
		return events

	def __prepare_events(self,events):
		new = []

		for event in events: 
			url = event[4]
			#log('evento: %s' % ev)
			league =event[0]
			#log('league: %s' % league)
			casa = event[1]
			ospite = event[2]
			#log('ospite: %s' % ospite)
			time = event[3]
			#log('time: %s' %time)
			title = u'(%s) [COLOR yellow][B] %s vs %s [/B][/COLOR] - [%s]'% (time, casa, ospite, league) 
			new.append((url, title))		
		return new 

	def resolve(self,url):
		from resources.lib.modules import liveresolver
		
		dialog = xbmcgui.Dialog()
		result = requests.get(url).text
		players = re.findall('url=[\"\'](.+?)[\"\']>Player', result)
		name = ['Link %s' % t for t in range(1, (len(players)+1))]
		index = dialog.select("Seleziona stream", name)
		if index != -1:
			url = players[index]

		d = liveresolver.Liveresolver().resolve(url)
		if d:
			if ".mpd" in d['url']:
				return d, False
			
			if "Referer=" in d['headers']:
				return '{}|{}'.format(d['url'], d['headers']), False
			return '{}|{}'.format(d['url'], urlencode(d['headers'])), False
		return ' '