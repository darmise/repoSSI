# -*- coding: UTF-8 -*-
from os import link
from resources.lib.modules import  webutils, control, cache, linkSearch, constants
from resources.lib.modules.log_utils import log
import re
import requests, xbmcgui
try:
	from urllib.parse import urlencode
except:
	from urllib import urlencode
try:
	from urllib.parse import urlparse
except:
	from urlparse import urlparse  # Python 2

class info():
	def __init__(self, url= ''):
		self.mode = 'calcio_str'
		self.name = '[COLOR yellow][B] Calcio[/B][/COLOR][COLOR white][B]Streaming[/B][/COLOR]'
		self.icon = "".join([urlparse(webutils.initSites("calcio_str_base")).scheme, '://', urlparse(webutils.initSites("calcio_str_base")).netloc, '/templates/calciostreaming1/images/logo.png'])
		self.enabled = control.setting("c_streaming") == "true"
		self.categorized = False
		self.paginated = False
		self.multilink = False

class main():
	
	def __init__(self):
		self.base = webutils.initSites('calcio_str_base')
		
	def events(self):
		headers = {'User-Agent': constants.USER_AGENT, 'referer': self.base}
		html = requests.get(self.base, headers=headers).text
		log('html %s' % html)
		events = re.findall('<a href=[\"\'](.+?)[\"\'] class="tile-image">\s+<img src=[\"\'](.+?)[\"\'] class[\s\S]*?title-2">\s+(.+?)\s+<\/', html)
		log('ERR: %s' % events)
		events = self.__prepare_events(events)
		#log('eventss: %s' % events)
		return events

	def __prepare_events(self,events):
		new = []
        
		for ev in events: 
			urltemp = ev[0]
			log('url: %s' % urltemp)
			img = 'https://'+ urlparse(self.base).netloc + ev[1]
			match = ev[2]
			url = self.__prepare_url(urltemp)
			#log('url %s' % url)
			title = '[COLOR yellow][B] %s [/B][/COLOR]'% (match) 
			new.append((url, title, img))		
		return new 

	def __prepare_url(self, urltemp):
		headers = {'User-Agent': constants.USER_AGENT, 'referer': urltemp}
		html = requests.get(urltemp, headers=headers).text
		log('html2 %s' % html)
		url = re.findall('link=[\"\'](.+?)[\"\']>[\s\S]*?>(.+?)<\/button>', html)
		return url	


	def resolve(self,urls):
		from resources.lib.modules import liveresolver
		
		urls = eval(urls)
		name = [u[1] for u in urls]
		url = [u[0] for u in urls]
		index = xbmcgui.Dialog().select("Seleziona stream", name)
		if index != -1:
			link = url[index]	
		
		d = liveresolver.Liveresolver().resolve(link)
		if d:
			#if d['url'].startswith('plugin://'):
			#	return d['url']
			return '{}|{}'.format(d['url'], urlencode(d['headers'])), False
		return link, True