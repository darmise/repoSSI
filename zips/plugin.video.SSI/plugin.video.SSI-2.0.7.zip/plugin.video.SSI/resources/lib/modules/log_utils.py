import xbmc
import xbmcaddon
import sys

addon = xbmcaddon.Addon()
name = addon.getAddonInfo('name')


def log(msg, level=xbmc.LOGINFO):

    try:
        if addon.getSetting('addon_debug') != 'true':
            return 
        
        level = xbmc.LOGINFO
        xbmc.log('%s: %s' % (name, msg), level)
    
    except Exception as e:
        try: xbmc.log('Logging Failure: %s' % (e), level)
        except: pass  # just give up
