import os, importlib

from resources.lib.modules.log_utils import log
from resources.lib.modules import connection
from resources.lib.modules import constants


BASE_DIR = os.path.dirname(__file__)

RESOLVERS = {
    f[:-3]: f[:-3]
    for f in os.listdir(BASE_DIR)
    if f.endswith(".py") and f != "__init__.py"
}

SESSION = connection.Connession()
SESSION.session.headers.update({
    "User-Agent": constants.USER_AGENT
})

def resolve(name_resolver, url, referer = '', referer_map={}):
    try:
        html = SESSION.get(url,allow_redirects=True, timeout=3, headers={'referer':referer}).text
    except:
        return None
    
    module_name = RESOLVERS.get(name_resolver)
    if not module_name:
        return None
    
    try:
        module = importlib.import_module(f".{module_name}", package=__package__)
        resolver_class = getattr(module, "Resolver", None)
        
        if resolver_class is None:
            return None
        
        resolver = resolver_class()
        
        if module_name == "wigistream":
            return resolver.resolve(url, html=html, referer=referer, referer_map=referer_map)
        
        return resolver.resolve(url, html=html, referer=referer)
    
    except Exception as e:
        log(f"Resolver error {module_name}: {e}")
        return None 
