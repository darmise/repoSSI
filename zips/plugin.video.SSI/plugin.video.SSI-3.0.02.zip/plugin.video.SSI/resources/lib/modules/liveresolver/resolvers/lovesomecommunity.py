import re
from urllib.parse import urlparse
from resources.lib.modules.log_utils import log
from resources.lib.modules import constants, connection


class Resolver():

    HEADERS = {
            "User-Agent": constants.USER_AGENT
    }
    
    def __init__(self):
        self.s = connection.Connession()
        self.s.session.headers.update(self.HEADERS)

    def resolve(self, url, html='', referer = None):
    
        if referer:
            self.s.session.headers["Referer"] = referer
        
        try:
            res = self.s.get(url, timeout=5).text
            lettera = re.findall('[\"\'](.+?)[\"\']].join', res)
            play_url = lettera[0].replace('"', '').replace(',', '').replace("\\", "")
            headers = {'Referer': "".join(['https://', urlparse(url).netloc]), 'User-Agent': constants.USER_AGENT}
            return {'url': play_url, 'headers': headers}
        except:
            return None