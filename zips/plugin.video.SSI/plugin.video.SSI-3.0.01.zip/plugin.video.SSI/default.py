import os, sys, importlib
import xbmcgui, xbmcplugin

from resources.lib.modules.addon import Addon
from resources.lib.modules import control, webutils, cache
from resources.lib.modules.log_utils import log
from urllib.parse import parse_qs

# ------------ ADDON SETTINGS ----------------
addon = Addon('plugin.video.SSI', sys.argv)
addon_handle = int(sys.argv[1])

if not os.path.exists(control.dataPath):
    os.mkdir(control.dataPath)

AddonPath = control.addonPath
IconPath = os.path.join(AddonPath, control.transPath("resources/media/"))
fanart = os.path.join(AddonPath, control.transPath("/fanart.jpg"))

# get mode by url
args = parse_qs(sys.argv[2][1:])
mode = args.get('mode', None)
path = f"{AddonPath}resources/lib/sources"
base = "resources.lib.sources"
#-------------------------------------------

# Functions
def icon_path(filename):
    if 'http' in filename:
        return filename
    return control.transPath(os.path.join(IconPath, filename))

def menu_sites():
    for s in os.listdir(path):
        if not s.endswith(".json"):
            continue
        try: 
            info = webutils.accessJSON(f"{path}/{s}")
            if info["enabled"]:
                addon.add_item(
                    {
                        'mode': 'open_site',
                        'site': info["mode"]
                    },
                    {
                        'label': info["name"],
                        'title': info["name"]
                    },
                    img=icon_path(info["icon"]),
                    fanart=fanart,
                    is_folder=True
                )
        except Exception as e:
            log(str(e))

#---------------------- MODES ---------------------------
if mode is None:   #navigation mode
    addon.add_item({'mode': 'ip'}, {'label': f"[COLOR blue] [B] Info connessione [/B] [/COLOR]", 'title':'Info'}, img=icon_path('info.png'), fanart=fanart,is_folder=True)
    menu_sites()
    addon.add_item({'mode': 'tools'}, {'label': '[COLOR lime] Impostazioni [/COLOR]', 'title':'Tools'}, img=icon_path('tools.jpg'), fanart=fanart,is_folder=True)
    webutils.updateJSON() 
    addon.end_of_directory()
    
    """
elif mode[0] == 'search':
    category = args['category'][0]

    keyboard = xbmc.Keyboard('', 'Enter search query:', False)
    keyboard.doModal()
    if keyboard.isConfirmed():
        
        query = keyboard.getText()
        xbmc.executebuiltin("Container.Update(%s)"%addon.build_plugin_url({'mode': 'open_search', 'query':query, 'category': category}))
    """
    """
elif mode[0]=='open_search':
    category = args['category'][0]
    query = args['query'][0]

    sources = os.listdir(AddonPath + '/resources/lib/sources/{}'.format(category))
    for source in sources:
        if '.pyo' not in source and '__init__' not in source and '__pycache__' not in source and '.pyc' not in source:
            try:
                site = source.replace('.py','')
                exec("from resources.lib.sources.{} import {}".format(category, site))
                info = eval(site+".info()")
                srch = False
                try: srch = info.searchable
                except: pass
                if srch:
                    s = eval(site+".main()")
                    events = s.search(query)
                    for event in events:
                        try:
                            img = icon_path(event[2])
                        except:
                            img = icon_path(info.icon)
                        if not info.multilink:
                            addon.add_item({'mode': 'play', 'category': category, 'url': event[0],'title':event[1], 'img': img,'site':site}, {'label': event[1], 'title': event[1].rstrip('[/B]')}, img=img, fanart=fanart, is_folder=False)
                        else:
                            if (control.setting('link_precheck') == 'false'):
                                ctxt = [('Rescrape links', 'RunPlugin(%s)'%addon.build_plugin_url({'mode': 'get_links_refresh', 'url': event[0], 'category': category, 'site':site , 'title':event[1], 'img': img, 'timeout': 'true'}))]
                            else:
                                ctxt = []
                            addon.add_item({'mode': 'get_links', 'url': event[0], 'category': category, 'site':site , 'title':event[1], 'img': img}, {'label': event[1],'title': event[1]}, img=img, fanart=fanart,  is_folder=True)
            except Exception as e:
                log("Error {} - {} - {}".format(category, site, e))
                pass

    addon.end_of_directory()
    """

elif mode[0] == 'open_site': #access to website
    site = args['site'][0]
    info = webutils.accessJSON(f"{path}/{site}.json")
    module = importlib.import_module(f"{base}.{site}")
    main = module.Main()
    
    try:
        events = main.events()
    except Exception as e:
            log(e)
            events = []
 
    for event in events:
        try:
            img = icon_path(event[2])
        except:
            img = icon_path(info["icon"])
            
        if info.get("multilink", False):
            if control.setting("link_precheck") == "false":
                ctxt = [
                    (
                        'Rescrape links',
                        'RunPlugin(%s)' % addon.build_plugin_url({
                        'mode': 'refresh_links',
                        'url': event[0],
                        'site': site,
                        'title': event[1],
                        'img': img
                        })
                    )
                ]
            else:
                ctxt = []
            addon.add_item(
                {
                    'mode': 'get_links',
                    'site': site,
                    'url': event[0],
                    'title': event[1],
                    'img': img
                },
                {
                    'label': event[1],
                    'title': event[1]
                },
                    img=img,
                    fanart=fanart,
                    contextmenu_items=ctxt,
                    is_folder=True
            )
        else: 
            addon.add_item({'mode': 'play', 'url': event[0],'title':event[1], 'img': img,'site':site}, {'label': event[1], 'title':event[1].rstrip('[/B]')}, img=img, fanart=fanart, is_folder=False)
    addon.end_of_directory()

elif mode[0] == 'refresh_links':
    url = args['url'][0]
    site = args['site'][0]
    
    
    try:
        module = importlib.import_module(f"{base}.{site}")
        main = module.Main()
        cache.remove(main._links, url)
    except Exception as e:
        log(f"refresh_links: {e}")
        
    xbmc.executebuiltin("Container.Refresh()")

elif mode[0]=='get_links':
    
    url = args['url'][0]
    title = args['title'][0]
    site = args['site'][0]
    img = args['img'][0]
 
    module = importlib.import_module(f"{base}.{site}")
    
    try:
        main = module.Main()
        events = main.links(url)
    except Exception as e:
        log(f"get_links error: {e}")
        events = []
    
    ctxt = []
    
    if (control.setting('link_precheck') == 'false'):
        ctxt = [
            (
                'Rescrape links',
                'RunPlugin(%s)' % addon.build_plugin_url({
                    'mode': 'refresh_links',
                    'url': url,
                    'site': site
                })
            )
        ]
    
    for link, label, img_e in events:
        
        item_img = img_e if img_e else img
        addon.add_item(
            {
                'mode': 'play',
                'url': link,
                'title': title,
                'img': item_img,
                'site': site
            },
            {
                'label': label,
                'title': title.rstrip('[/B]')
            },
            img=item_img,
            fanart=fanart,
            contextmenu_items=ctxt,
            is_folder=False
        )
        
    if not events:
        addon.add_item(
            {
                'mode': 'refresh_links',
                'url': url,
                'site': site
            },
            {
                'label': 'Rescrape links',
                'title': 'Rescrape links'
            },
            img=img,
            fanart=fanart,
            is_folder=False
        )
    
    addon.end_of_directory()

   

elif mode[0] == 'play':
    url = args['url'][0]
    title = args['title'][0]
    #category = args['category'][0]
    img = args['img'][0]
    site = args['site'][0]
    module = importlib.import_module(f"{base}.{site}")
    main = module.Main()
    enc = False
    try:
        resolved, enc = main.resolve(url)
    except:
        resolved = main.resolve(url)
    #log("resolved %s" % resolved)
    if resolved:
        
        if 'm3u8' in resolved or "M3U4" in resolved:
            li = xbmcgui.ListItem(title, path=resolved)
    
            li.setArt({'thumb': img, 'icon': img, 'poster': img})
            li.setProperty('inputstream', 'inputstream.ffmpegdirect')
            li.setMimeType('application/vnd.apple.mpegurl')
            li.setProperty('inputstream.ffmpegdirect.is_realtime_stream', 'true')
            li.setProperty('inputstream.ffmpegdirect.manifest_type', 'hls')
            li.setProperty('inputstream.ffmpegdirect.stream_mode', 'live')

            li.setContentLookup(False)
            li.setProperty("IsPlayable", 'true')
            xbmcplugin.setResolvedUrl(handle=int(sys.argv[1]), succeeded=True, listitem=li)
            
            
        elif '..css' in resolved["url"]: # NON FUNZIONANTE
            li = xbmcgui.ListItem(title, path=resolved["url"])
            li.setMimeType("application/vnd.apple.mpegurl")
            li.setContentLookup(False)
            li.setProperty("IsPlayable", "true")

            li.setProperty("inputstream", "inputstream.adaptive")
            li.setProperty("inputstream.adaptive.manifest_type", "hls")

            headers = resolved["headers"]
            url_server = resolved["license_server"]
            
            li.setProperty("inputstream.adaptive.license_type", "com.widevine.alpha")
            li.setProperty("inputstream.adaptive.license_key", url_server + "|" + headers + "|R{SSM}|")
            xbmcplugin.setResolvedUrl(handle=int(sys.argv[1]), succeeded=True, listitem=li)
        
        else: 
            li = xbmcgui.ListItem(title, path=resolved['url'], offscreen=True)
            li.setArt({'thumb': img})
            li.setMimeType('application/dash+xml')
            li.setContentLookup(False)
                    
            li.setProperty('inputstream', 'inputstream.adaptive')
            li.setProperty("inputstream.adaptive.manifest_type", "mpd")

            if resolved.get('clearkeys'):
                """
                if resolved['clearkeys'] == 'widevine':
                    log("TESTIAMO")
                    li.setProperty('inputstream.adaptive.license_type', 'com.widevine.alpha')
                    li.setProperty('inputstream.adaptive.license_key', 'https://vdp654rf.anycast.nagra.com/VDP654RF/prls/contentlicenseservice/v1/licenses|Content-Type=application/octet-stream&Origin=https://tv.vodafone.pt&Referer=https://tv.vodafone.pt/|R{SSM}|')
                
                else:"""	
                drm = "".join(['org.w3.clearkey', resolved['clearkeys']])
                li.setProperty('inputstream.adaptive.drm_legacy', drm)

            xbmcplugin.setResolvedUrl(handle=int(sys.argv[1]), succeeded=True, listitem=li)
            
########################################################################################################################################################################################################
########################################################################################################################################################################################################
########################################################################################################################################################################################################
####
####______________________________________________________________________________________________TOOLS_________________________________________________________________________________________________
####
########################################################################################################################################################################################################
########################################################################################################################################################################################################
########################################################################################################################################################################################################

elif mode[0]=='tools':
    addon.add_item({'mode': 'settings'}, {'label':'[COLOR lime] Configura Addon [/COLOR]', 'title':'Settings'}, img=icon_path('tools.jpg'), fanart=fanart,is_folder=True)
    addon.add_item({'mode': 'clear_cache'}, {'label':'[COLOR lime] Pulisci Cache [/COLOR]', 'title':'Clear addon cache'}, img=icon_path('tools.jpg'), fanart=fanart,is_folder=True)
    addon.add_item({'mode': 'clear_json'}, {'label':'[COLOR lime] Pulisci JSON [/COLOR]', 'title':'Clear addon json'}, img=icon_path('tools.jpg'), fanart=fanart,is_folder=True)
    addon.end_of_directory()

elif mode[0]=='clear_cache':
    cache.clear()

elif mode[0]=='settings':
    control.openSettings()

elif mode[0]=='clear_json':
    webutils.clearJSON()	
 
elif mode[0] == 'ip':
    ip, loc = webutils.get_ip_information()
    control.infoDialog(f"[COLOR blue] IP:[B] {ip} [/B]- Paese:[B] {loc} [/B][/COLOR]", icon=icon_path('info.png'))    
##################################################################################################################################
