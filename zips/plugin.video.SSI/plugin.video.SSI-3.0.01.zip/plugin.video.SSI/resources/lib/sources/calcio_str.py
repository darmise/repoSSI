import re, xbmcgui

from urllib.parse import urlparse
from resources.lib.modules import  webutils, connection, constants, liveresolver
from resources.lib.modules.log_utils import log

class Main():
    
    HEADERS = {
        "User-Agent": constants.USER_AGENT
    }
    
    EVENT_RE = re.compile(
        r'<a href=["\'](.+?)["\'] class="tile-image">[\s\S]*?'
        r'<img src=["\'](.+?)["\'][\s\S]*?'
        r'center">(.+?)<[\s\S]*?title">(.+?)<'
    )
    
    PAGE_RE = re.compile('link=[\"\'](.+?)[\"\']>[\s\S]*?>(.+?)<\/button>')
    
    def __init__(self):
        self.base = webutils.initSites('calcio_str_base')
        self.s = connection.Connession()
        self.s.session.headers.update(self.HEADERS)
        self.resolver = liveresolver.Liveresolver()
        
    def events(self):
        self.s.session.headers["Referer"] = self.base
        html = self.s.get(self.base, timeout=5).text
        
        return [
            (self.__prepare_url(ev[0]),
                f'[COLOR yellow][B] {ev[0].rsplit("/", 1)[-1].split("-", 1)[1].rsplit("-online-gratis.html", 1)[0][:-8].replace("-", " ")} [/B][/COLOR]',
                f'https://{urlparse(self.base).netloc}{ev[1]}')
            for ev in self.EVENT_RE.findall(html)
        ]

    def __prepare_url(self, urltemp):
        self.s.session.headers["Referer"] = urltemp
        html = self.s.get(urltemp, timeout = 5).text
        url = self.PAGE_RE.findall(html)
        return url	


    def resolve(self,urls):
        
        urls = eval(urls)
        index = xbmcgui.Dialog().select("Seleziona stream", [u[1] for u in urls])
        
        if index == -1:
            return None, False	
        
        d = self.resolver.resolve(urls[index][0])
        url = d["url"]
        headers = d["headers"]
        
        if ".mpd" in url:
            return d, False
            
        elif "Referer=" in headers:
            return f'{url}|{headers}', False
            
        header_string = "&".join(f"{k}={v}" for k,v in headers.items())
        return f'{url}|{header_string}', False
    
    
    