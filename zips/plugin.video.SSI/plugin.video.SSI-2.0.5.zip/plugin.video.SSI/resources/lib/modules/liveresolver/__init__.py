from .modules import adhosts
from . import resolvers
from resources.lib.modules.log_utils import log
from resources.lib.modules.constants import USER_AGENT
from resources.lib.modules import control
from resources.lib.modules import webutils, hunter
import threading, base64, os, re, requests
import time 
from urllib.parse import urlparse, unquote



class Liveresolver:

	def __init__(self, headers = {'user-agent': USER_AGENT}):
		self.headers = headers	
		self.session = requests.Session()
		self.session.headers.update(headers)
		self.referer_map = {}
		self.player_referer = 'ezcaster'

	"""
	def resolve(self, url):
		start = time.time()
		try:
			u = self.__resolve(url)
			end = time.time()
			end = time.time()
			log("TEMPO")
			log(end-start)
			return u
		except:
			return 
	"""
	#def resolve(self, url, name = ''):
	
	
	def resolve(self, url):
		#if '.m3u8' in url:
		#	return {'url': url, 'headers': {'user-agent': USER_AGENT}}
		resolved = []
		start = time.time()
		#t = Thread(self.__resolve, name, url, resolved)
		t = Thread(self.__resolve, url, resolved)
		t.start()
		#t1 = time.time()
		#TIMEOUT = int(control.setting("resolver_timeout"))
		#while t.is_alive():
		#	if ((time.time() - t1) > TIMEOUT):
				#log('Liveresolver resolve timeout for url: ' + url)
		#		del t
		#		break
		try:
			t.join()
			u = resolved[0]
		except:
			u = None
		end = time.time()
		log(end-start)

		return u
	
	#def __resolve(self, name, url):
	def __resolve(self, url):
		self.url = url
		#self.url = self.url.replace('http:http:', 'http:')
		#url = self.url
		self.referer_map[self.url] = ''
		
		#log('stringa %s' % base_calcio)
		#log('self referer map resolve: %s' %self.referer_map[self.url])
		#check if first url is resolvable
		#try:
		#	html = self.session.get(self.url, timeout=10).text
		#except Exception as e:
		#	log('Liveresolver: Error while trying to access {}: \n\n{}'.format(url,e))
		#	return None
		'''
		supported = resolvers.check(name)
		if len(supported) > 0:
			resolved = resolvers.resolve(name, url, self.referer_map[url], self.referer_map)
			if resolved:
				return resolved
		'''
		log("url res %s " % url)
		
		iframes = self.__findIframes(self.url, links=[url])
		iframes = self.clearIframes(iframes, url)
		iframes = sorted(iframes, key=len, reverse=True)
		log('iframes %s' % iframes)
		
		resolved = None
		
		data = webutils.accessJSON(os.path.join(os.path.dirname(__file__), 'json_data.json'))
		names = [el['name'] for el in data]

		for l in iframes:
			log('l %s' % l)

			if 'remote=no_check_ip' in l: #stream diretti
				u = l.replace("embed.html", "tracks-v1/index.fmp4.m3u8").replace("&remote=no_check_ip", "")
				resolved = resolvers.resolve('genericm3u8', u, referer=l)
				return resolved
		
			for el in data:
				if el["name"] in l:
					resolved = resolvers.resolve(el["resolve"], l, self.referer_map[l], self.referer_map)	
			
			if resolved is None:
				resolved = self.searchResolve(l, names)
			
			if resolved:
				break
		
		return resolved
		"""
	def resolve_search(self, url):
		self.url = url
		self.url = self.url.replace('http:http:', 'http:')
		url = self.url
		self.referer_map[self.url] = ''
		
		#else go through iframes
		iframes = self.__findIframes(self.url, links=[url])
		resolved = None
		for l in iframes:
			resolved = resolvers.resolve(l, self.referer_map[l], self.referer_map)
			if resolved:
				break
		
			
		return resolved
		"""
	def searchResolve(self, l, names):
		resolves = ['daddylive', 'genericm3u8', 'wigistream', 'lovesomecommunity', 'mpd_stream']
		for res in resolves:
			log(res)
			result = resolvers.resolve(res, l, self.referer_map[l], self.referer_map)
		
			if result and l not in names:
				self.salvaJSON(l, res)
				return result
		return None
	
	def salvaJSON(self, name, res):
		lista = webutils.accessJSON(os.path.join(os.path.dirname(__file__), 'json_data.json'))
		lista.append({
				"name": name,
				"resolve": res
			})
		webutils.saveJSON(lista, os.path.join(os.path.dirname(__file__), 'json_data.json'))
		return ""
	
	def __findIframes(self, url, links = [], checked = []):
		links = links
		checked = checked
		#try:
		#	self.session.headers.update({'Referer': self.referer_map[url]})
		#except:
		#	pass		
		
		if self.player_referer in url: #problem connection: want referer
			self.referer_map[url] = "".join([urlparse(webutils.initSites("calcioga_base")).scheme, '://', urlparse(webutils.initSites("calcioga_base")).netloc])
		
		try:
			r = self.session.get(url, allow_redirects=True, timeout=5, headers={'User-Agent': USER_AGENT, 'referer': self.referer_map[url], 'sec-fetch-dest': 'iframe'})
			#log(r.text)
		except Exception as e:
			log('Liveresolver: Error while trying to access {}: \n\n{}'.format(url,e))
			return []
		
		if r.status_code == 200:
			urls = re.findall('i?frame\s*.+?src=[\"\']?([^\"\']+)', r.text, flags=re.IGNORECASE)
			
			api = re.findall(">\s+fetch\([\"\'](.+?)[\"\']", r.text)
			if api:
				u = requests.get('https://' + urlparse(url).netloc+'/'+api[0]).json()["url"]
				urls.append(u)
			urls = self.__customUrls(r.text, url, urls)
			
			for u in urls:
				
				if urlparse(u).netloc == '':
					if u.startswith('/'):	
						u = 'http://' + urlparse(url).netloc + '/' + u
					else:
						u = 'http://' + urlparse(url).netloc + '/'.join(urlparse(url).path.split('/')[:-1]) +  '/' + u
				
				if urlparse(u).scheme == '':
					u = 'http://' + u.replace('//','')
	
				u = re.sub(r'\n+', '', u)
				u = re.sub(r'\r+', '', u)
				
				#if not adhosts.isAd(u) and u not in checked and self.__checkUrl(u) and u not in links and len(links)<15:
				#if not adhosts.isAd(u) and u not in checked and u not in links and len(links)<15:
				
				if u not in checked and u not in links and len(links) < 15:
					links.append(u)
					#if 'castmax.me' in u:
					#	self.referer = 'https://castmax.live/'
					#log('referer: %s' % self.referer)
					self.referer_map[u] = url 
					links += self.__findIframes(u, links, checked)
					checked.append(u)
			return list(set(links))
			
		return []
	
	def __customUrls(self, r, ref, urls): 
		fid = re.findall('fid\s*=\s*[\"\']([^\"\']+)[\"\']', r) 
		#m3u8 = re.findall('[\"\'](.+?m3u8.+?)[\"\']', r)
		#tiny = re.findall('href\s*=\s*[\"\']([^\"\']+).+?class\s*=\s*[\"\']btn\s*btn\-secondary', r)
		unes = re.findall('=\s*[\"\']([^\"\']+)[\"\']+[^\"\']+unescape', r)
		multiline = re.findall('i?frame\s*.+?src=[\"\']?([^\"\']+)', r, flags=re.IGNORECASE | re.DOTALL)
		#telerium = re.findall("'iframe',[\"\'](.+?)[\"\']", r)
		atob = re.findall(r"(?:window.atob\([\"\'](.+?)[\"\']|canal = [\"\'](.+?)[\"\'])", r)
		#src_only = re.findall('(allowfullscreen)*\s*src=[\"\'](.+?)[\"\']\s*(allowfullscreen)*', r)
		#data_src = re.findall('i?frame\s*.+?data\s*.+?src=[\"\']?([^\"\']+)', r, flags=re.IGNORECASE | re.DOTALL)
		#url_in_url = bool(re.search('streamlink\.slice\(4\)', r))
		us = []

		if len(fid) > 0:
			domain = re.findall("text\/javascript' src=[\"\']([^\"\']+).js", r)
			u = ''.join(["https:", domain[0], ".php?player=desktop&live=", fid[0]])
			urls.append(u)

		#if len(m3u8) > 0:
		#	u = m3u8[0].replace("\\", "")
		#	urls.append(u)

		#if len(src_only) > 0:
		#	log(src_only)
		#	urls = [x for t in src_only for x in t]

		if len(atob) > 0:
			u = base64.b64decode(next(x for x in atob[0] if isinstance(x, str) and x.strip())).decode('utf-8')
			urls.append(u)

		#if len(tiny) > 0:
		#	urls.append(tiny[0])
		#	self.referer_map[tiny[0]] = ref

		if len(unes) > 0:
			u = unes[0].replace('@', '%')
			import urllib.parse
			#html = urllib.unquote(u).decode('utf8')
			html = urllib.parse.unquote(u)
			try:
				u = re.findall('i?frame\s*.+?src=[\"\']?([^\"\']+)', html, re.IGNORECASE)[0]
				us.append(u)
				self.referer_map[u] = ref
			except:
				pass
		if len(multiline) > 0:
			for u in multiline:
				us.append(u)
		
		#if len(data_src) > 0:
		#	for u in data_src:
		#		urls.append(u)
		
		#if url_in_url:
		#	u = re.findall('\?.{3}([^$]+)', ref)[0]
		#	self.referer_map[u] = ref
		#	us.append(u)
		#for u in us:
			#if not adhosts.isAd(u) and self.__checkUrl(u) and u not in urls:
		#	if not adhosts.isAd(u) and u not in urls:
		#		urls.append(u)
		return urls
		
	def clearIframes(self, iframe_list, link):
		blacklist = (',', 'adserv', 'javascript', ';', 'ads.com', '.js', 
				'ad4', '()', '.svg', '/https', 'soccer.store', '/\\',
				"premiumtv/t", self.player_referer)
		cleared = []

		for s in iframe_list:
			if not any(b in s for b in blacklist):
				cleared.append(s)

		if not link.endswith(".m3u8") and link in cleared:
			cleared.remove(link)
		return cleared
	
	"""
	def __checkUrl(self, url):
		blacklist = ['chatango', 'adserv', 'live_chat', 'ad4', 'cloudfront', 'image/svg', 'getbanner.php','/ads', 'ads.', 'adskeeper', '.js', '.jpg', '.png', '/adself.', 'min.js',
					'mail.ru']
		return not any(w in url for w in blacklist)
		"""
	
	"""
	def __customUrls(self, r, ref, urls):
		fid = re.findall('fid\s*=\s*[\"\']([^\"\']+)[\"\']', r) 
		m3u8 = re.findall('[\"\'](.+?m3u8.+?)[\"\']', r)
		#tiny = re.findall('href\s*=\s*[\"\']([^\"\']+).+?class\s*=\s*[\"\']btn\s*btn\-secondary', r)
		unes = re.findall('=\s*[\"\']([^\"\']+)[\"\']+[^\"\']+unescape', r)
		multiline = re.findall('i?frame\s*.+?src=[\"\']?([^\"\']+)', r, flags=re.IGNORECASE | re.DOTALL)
		#telerium = re.findall("'iframe',[\"\'](.+?)[\"\']", r)
		#atob = re.findall("window.atob\([\"\'](.+?)[\"\']", r)
		#src_only = re.findall("allowfullscreen=[\s\S]*?src=[\"\'](.+?)[\"\']", r)
		#data_src = re.findall('i?frame\s*.+?data\s*.+?src=[\"\']?([^\"\']+)', r, flags=re.IGNORECASE | re.DOTALL)
		us = []

		if len(fid) > 0:
			domain = re.findall("text\/javascript' src=[\"\']([^\"\']+).js", r)
			u = f"https:{domain[0]}.php?player=desktop&live={fid[0]}"
			urls.append(u)

		#if src_only:
		#	urls.append(src_only[0])

		if len(m3u8) > 0:
			u = m3u8[0].replace("\\", "")
			urls.append(u)

		#if atob:
		#	u = base64.b64decode(atob[0]).decode('utf-8')
		#	urls.append(u)

		#if atob2:
		#	u = base64.b64decode(atob2[0]).decode('utf-8')
		#	urls.append(u)

		#if tiny:
		#	urls.append(tiny[0])
		#	self.referer_map[tiny[0]] = ref

		if len(unes) > 0:
			u = unes[0].replace('@', '%')
			html = unquote(u)
			try:
				u = re.findall('i?frame\s*.+?src=[\"\']?([^\"\']+)', html, re.IGNORECASE)[0]
				us.append(u)
				self.referer_map[u] = ref
			except:
				pass

		if len(multiline) > 0:
			#log(multiline)
			for u in multiline:
				us.append(u)
			
		#if data_src:
		#	for u in data_src:
		#		urls.append(u)
			
		#if url_in_url:
		#	u = re.findall('\?.{3}([^$]+)', ref)[0]
		#	self.referer_map[u] = ref
		#	us.append(u)
		return urls
	"""
	"""
	def clearIframes(self, list):
		chars = [',', 'adserv', 'javascript', ';', 'ads.com', '.js', 'ad4', '()', '.svg', '/https', 'soccer.store', '/\\', self.player_referer]
		list2 = []

		for s in list:
			if all(c not in s for c in chars):
				list2.append(s)
		return list2
"""
'''
class Thread(threading.Thread):
	def __init__(self, func, arg1, arg2, out):
		self.func = func
		self.arg1 = arg1
		self.arg2 = arg2
		self.out = out
		self._return = None
		threading.Thread.__init__(self)

	def run(self):
		try:
			resolved = self.func(self.arg1, self.arg2)
			self.out.append(resolved)
		except Exception as e:
			log("Liveresolver thread error: " + str(e))
			self.out.append(None)
'''
class Thread(threading.Thread):
	def __init__(self, func, url, out):
		self.func = func
		self.url = url
		self.out = out
		self._return = None
		threading.Thread.__init__(self)

	def run(self):
		try:
			resolved = self.func(self.url)
			self.out.append(resolved)
		except Exception as e:
			log("Liveresolver thread error: " + str(e))
			self.out.append(None)
		
		