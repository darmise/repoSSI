# -*- coding: UTF-8 -*-
from os import link
from resources.lib.modules import  webutils, control, cache, linkSearch, constants
from resources.lib.modules.log_utils import log
import re, xbmcgui, requests
from resources.lib.modules import liveresolver

from urllib.parse import urlencode, quote_plus, unquote_plus

class info():
	def __init__(self, url= ''):
		self.mode = 'hattrick'
		self.name = '[COLOR lime][B] Hattrick [/B][/COLOR]'
		self.icon = 'https://logowiki.net/wp-content/uploads/imgp/Hattrick-Logo-1-5512.jpg'
		self.enabled = control.setting("hat") == 'true'
		self.categorized = False
		self.paginated = False
		self.multilink = False 

class main():
	
	def __init__(self):
		self.base = webutils.initSites('hattrick_base')

	def events(self):
		html_full = requests.get(self.base).text
		log(html_full)
		events = re.findall('<span>(.+?)<span><\/a>([\s\S]*?)ton>\s+<\/div>', html_full)
		log(events)
		events = self.__prepare_events(events)
		return events 

	def __prepare_events(self,events):
		new=[]
		for ev in events:
	
			urls = re.findall('href=[\"\'](.+?)[\"\'] target="_blank">(.+?)<\/', ev[1])
			time_list = re.findall('>(.+?)Â', ev[1])
			time = time_list[0].strip() if time_list else "Live"
			match = ev[0]
			title = u"[COLOR red](%s)[/COLOR][COLOR yellow] - [B] %s [/B][/COLOR]" % (time, match)
			new.append((urls, title))

		return new
	
	def resolve(self,url):
		url = eval(url)
		url = [u for u in url if all("pass" not in i and "(" not in i for i in u)]

		dialog = xbmcgui.Dialog()
		streams = [u[0] for u in url]
		name = [u[1] for u in url]
		index = dialog.select("Seleziona stream", name)
		if index != -1:
			link =	streams[index]
		
		d = liveresolver.Liveresolver().resolve(link)
		
		if d:
			if ".mpd" in d['url']:
				return d, False
			
			if "Referer=" in d['headers']:
				return '{}|{}'.format(d['url'], d['headers']), False
			#elif "mpd" in d['url']:
			#	return '{}|{}'.format(d['url'], d['headers']), False
			return '{}|{}'.format(d['url'], urlencode(d['headers'])), False
		return link, True
		
