# -*- coding: UTF-8 -*-
from os import link
from resources.lib.modules import  webutils, control, cache, linkSearch, constants
from resources.lib.modules.log_utils import log
import re
import requests, xbmcgui
try:
	from urllib.parse import urlencode
except:
	from urllib import urlencode

class info():
	def __init__(self, url= ''):
		self.mode = 'neymartv'
		self.name = '[COLOR blue][B] N[/B][/COLOR][B]eymar[/B][COLOR blue] TV [/COLOR]'
		self.icon = 'https://blogger.googleusercontent.com/img/a/AVvXsEhckGK5JGthhLUu1Nx2-ZGi2gOyRytQVRgM6ZtvF1D0F0u-38QkbQmD6JEZd2E8QluywhJ2gI05NdtzVmYY-iBhgDdS6frDo-yd-b1i_-j2fb2Gi4YL_pWFxbYp-mAJ94mPEx1OqpzBz_b4UFx7j58OXvLlgeU5xq3lPkCwsSzEznKpkgeEZn3wQAg3=w800'
		self.enabled = control.setting("ney") == 'true'
		#self.enabled = True
		self.categorized = False
		self.paginated = False
		self.multilink = False

class main():
	
	def __init__(self):
		self.base = control.setting('neymar_base')
	
	def events(self):
		headers = {'User-Agent': constants.USER_AGENT, 'referer': self.base}
		result = requests.get(self.base, headers=headers).text
		index1 = result.find("ITALY | ITALIA TV")
		index2 = result.find("IRELAND | SCOTLAND TV")
		result2 = result[index1:index2]
    
		events = re.findall('<button [\s\S]*? onclick="document.location=[\"\'](.+?)[\"\'] " role="button">(.+?)<\/button>', result2)
		
		events = self.__prepare_events(events)
		return events

	def __prepare_events(self,events):
		new = []
		for ev in events: 
			url = ev[0]
			channel = ev[1]
			title = '[COLOR lime][B] %s[/B][/COLOR]'% (channel)
			new.append((url,title))	
			
		return new	
	
	def resolve(self, url):
		from resources.lib.modules import liveresolver
		
		streams, lst = self.__prepare_resolve(url)
		dialog = xbmcgui.Dialog()
		index = dialog.select("Seleziona stream", lst)
		
		url = ""
		if index != -1:
			url = streams[index]		
		d = liveresolver.Liveresolver().resolve(url)
		if d:
			#if d['url'].startswith('plugin://'):
			#	return d['url']
			return '{}|{}'.format(d['url'], urlencode(d['headers'])), False
		return url, True

	def __prepare_resolve(self, url):
		hea = {'User-Agent': constants.USER_AGENT,'Host': 'www.neymartv.net'}
		url = url.replace("http", "https")[:-1]
		
		try:
			html = requests.get(url, headers=hea).text
			#log("html %s" % html)
		except:
			pass	
		play_urls = re.findall('<li movieurl=[\"\'](.+?)[\"\']><a>(.+?)<', html)
		urls = [play_urls[i][0] for i in range(0, len(play_urls))]
		names = [('Link %s' % y)  for y in range(1, len(play_urls))]
		return urls, names
	