# -*- coding: UTF-8 -*-
from os import link
from resources.lib.modules import  webutils, control, constants
from resources.lib.modules.log_utils import log
import re, xbmcgui
import requests
try:
	from urllib.parse import urlencode
except:
	from urllib import urlencode

class info():
	def __init__(self):
		self.mode = 'roja'
		self.name = '[COLOR red][B] Rojadirecta [/COLOR][/B]'
		self.icon = 'http://www.rojadirecta.eu/static/roja.jpg'
		self.enabled = control.setting("roja") == 'true'
		self.categorized = False
		self.paginated = False
		self.multilink = True

class main():
	def __init__(self, url = ''):
		self.base = webutils.initSites('roja_base')
		#log(self.base)
	
	def links(self, urls):
		links = re.findall('<tr>\s+<td>(.+?)<\/td>\s+<td>(.+?)<\/td>\s+<td>(.+?)<\/td>\s+<td>(.+?)<\/td>\s+<td>(.+?)<\/td>\s+<td>(.+?)<\/td>', urls)
		#log("links %s" % links)
		links = self.__prepare_links(links)
		return links
	
	def __prepare_links(self,links):
		links = links[1:]
		#log("links %s" % links)
		new=[]        
		count = 0
		for l in links:
			count = count + 1	
			name = l[1]
			lang = l[2]
			kbps = l[4]
			tempurl = l[5]
			url = re.findall('href=[\"\'](.+?)[\"\']', tempurl)[0]
			title = "%d - [COLOR yellow][B] %s [/B][/COLOR] (%s, %skbps)" % (count, name, lang, kbps)
			new.append((url,title, info().icon))
		return new
	
	def events(self):
		headers = {'User-Agent': constants.USER_AGENT, 'referer': self.base}
		result = requests.get(self.base, headers=headers).text
		reg = re.compile('"t">(.+?)<\/span>[\s\S]*?<\/span> (.+?) <b>[\s\S]*?>(.+?)<\/([\s\S]*?)<\/span>\s+<\/span>')
		events = re.findall(reg,result)
		#log(result)
		#log('events %s' % events)
		events = self.__prepare_events(events)
		return events
	
	def __prepare_events(self,events):
		new = []
		for event in events:
			time = event[0]
			league = event[1].replace(":", "").replace('<span class="es">Calcio</span><span class="en">Calcio</span> ', "").replace('<span class="es">Basket</span><span class="en">Basket</span> ', "").replace('<span class="es">Tennis</span><span class="en">Tennis</span>', "").replace('<span class="es">Pallavolo</span><span class="en">Pallavolo</span>', "").replace('<span class="es">Baseball</span><span class="en">Baseball</span>', "").replace('<span class="es">Pallamano</span><span class="en">Pallamano</span>', "").replace('<span class="es">Cricket</span><span class="en">Cricket</span>', "")
			partita = event[2].strip()
			#log(league)
			urls = event[3]
			title = u'(%s) [COLOR yellow][B] %s [/B][/COLOR] - [COLOR lime] %s [/COLOR]' % (time, partita, league)
			new.append((urls,title, info().icon))
			
		return new
	
	def resolve(self,url):
		from resources.lib.modules import liveresolver
		
		d = liveresolver.Liveresolver().resolve(url)
		if d:
			if "Referer=" in d['headers']:
				return '{}|{}'.format(d['url'], d['headers']), False
			#if d['url'].startswith('plugin://'):
			#	return d['url']
			return '{}|{}'.format(d['url'], urlencode(d['headers'])), False
		return url, True