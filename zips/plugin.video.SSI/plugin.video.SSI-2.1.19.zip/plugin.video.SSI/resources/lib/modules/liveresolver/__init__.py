from .modules import adhosts
from . import resolvers
from resources.lib.modules.log_utils import log
from resources.lib.modules.constants import USER_AGENT
from resources.lib.modules import control
from resources.lib.modules import webutils, hunter, constants
import threading, base64, os, re, requests, json
import time 
from urllib.parse import urlparse, unquote



class Liveresolver:

	def __init__(self, headers = {'user-agent': USER_AGENT}):
		self.headers = headers	
		self.session = requests.Session()
		self.session.headers.update(headers)
		self.referer_map = {}
		self.player_referer = 'ezcaster'

	"""
	def resolve(self, url):
		start = time.time()
		try:
			u = self.__resolve(url)
			end = time.time()
			end = time.time()
			log("TEMPO")
			log(end-start)
			return u
		except:
			return 
	"""
	#def resolve(self, url, name = ''):
	
	
	def resolve(self, url):
		#if '.m3u8' in url:
		#	return {'url': url, 'headers': {'user-agent': USER_AGENT}}
		resolved = []
		start = time.time()
		#t = Thread(self.__resolve, name, url, resolved)
		t = Thread(self.__resolve, url, resolved)
		t.start()
		#t1 = time.time()
		#TIMEOUT = int(control.setting("resolver_timeout"))
		#while t.is_alive():
		#	if ((time.time() - t1) > TIMEOUT):
				#log('Liveresolver resolve timeout for url: ' + url)
		#		del t
		#		break
		try:
			t.join()
			u = resolved[0]
		except:
			u = None
		end = time.time()
		log(end-start)

		return u
	
	#def __resolve(self, name, url):
	def __resolve(self, url):
		#url = "https://dlstreams.top/stream/stream-869.php"
		self.url = url
		#self.url = self.url.replace('http:http:', 'http:')
		#url = self.url
		self.referer_map[self.url] = ''
		
		#log('stringa %s' % base_calcio)
		#log('self referer map resolve: %s' %self.referer_map[self.url])
		#check if first url is resolvable
		#try:
		#	html = self.session.get(self.url, timeout=10).text
		#except Exception as e:
		#	log('Liveresolver: Error while trying to access {}: \n\n{}'.format(url,e))
		#	return None
		'''
		supported = resolvers.check(name)
		if len(supported) > 0:
			resolved = resolvers.resolve(name, url, self.referer_map[url], self.referer_map)
			if resolved:
				return resolved
		'''
		log("url res %s " % url)
		
		iframes = self.__findIframes(self.url, links=[url])
		iframes = self.clearIframes(iframes, url)
		iframes = sorted(iframes, key=len, reverse=True)
		if not iframes: 
			iframes = [url]
		#log('iframes %s' % iframes)
		
		resolved = None
		
		data = webutils.accessJSON(os.path.join(os.path.dirname(__file__), 'json_data.json'))
		names = [el['name'] for el in data]

		for l in iframes:
			log('l %s' % l)

			if '&remote=' in l:
				u = l.replace("embed.html", "index.fmp4.m3u8").replace("&remote=None", "")
				resolved = resolvers.resolve('genericm3u8', u, referer=l)
				return resolved
			
			elif "extension://" in l:
				l2 = l.split("#")[1]
				if "m3u8" in l2:
					if "headers" not in l2:
						resolved = resolvers.resolve('genericm3u8', l2)
						return resolved
					
					l2 = l2.split("&") 
					u = l2[0]
					code = l2[1].replace("headers=", "")
					code += "=" * (-len(code) % 4)
					decoded = eval(base64.b64decode(code).decode("utf-8"))
					resolved = resolvers.resolve('genericm3u8', u, referer=decoded["referer"])
					return resolved

				else:
					l2 = l2.split("ck=")
					play_url = l2[0].rstrip("?").rstrip("&")
					"""
					if "rr.cdn.vodafone.pt" in play_url: #-> CDN VODAFONE
						play_url = requests.get(play_url, headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36"}, allow_redirects=True, verify=False).url
						play_url = re.sub(':\d{3}', '', play_url)
						return {'url': play_url, 'clearkeys': 'widevine'} #widivine
					"""	
					
					if len(l2) > 1:
						code = l2[1]
						if "=" not in code:
							code += "=" * (-len(code) % 4)
						clearkeys = base64.b64decode(code).decode("utf-8")
						log(clearkeys)
						if "{" in clearkeys:
							kid, key = list(json.loads(clearkeys).items())[0]
							clearkeys = f"{kid}:{key}" 
						clearkey = f'|{clearkeys}'
						return {'url': play_url, 'clearkeys': clearkey}
					
					else: 
						return {'url':play_url, 'clearkeys': ''}
					

			for el in data:
				if el["name"] in l:
					resolved = resolvers.resolve(el["resolve"], l, self.referer_map[l], self.referer_map)	
			
			if resolved is None:
				resolved = self.searchResolve(l, names)
			
			if resolved:
				break
		
		return resolved
		"""
	def resolve_search(self, url):
		self.url = url
		self.url = self.url.replace('http:http:', 'http:')
		url = self.url
		self.referer_map[self.url] = ''
		
		#else go through iframes
		iframes = self.__findIframes(self.url, links=[url])
		resolved = None
		for l in iframes:
			resolved = resolvers.resolve(l, self.referer_map[l], self.referer_map)
			if resolved:
				break
		
			
		return resolved
		"""
	def searchResolve(self, l, names):
		resolves = ['api_m3u8', 'genericm3u8', 'wigistream', 'lovesomecommunity', 'mpd_stream']#daddylive out
		for res in resolves:
			log(res)
			result = resolvers.resolve(res, l, self.referer_map[l], self.referer_map)
		
			if result and l not in names:
				self.salvaJSON(l, res)
				return result
		return None
	
	def salvaJSON(self, name, res):
		lista = webutils.accessJSON(os.path.join(os.path.dirname(__file__), 'json_data.json'))
		lista.append({
				"name": name,
				"resolve": res
			})
		webutils.saveJSON(lista, os.path.join(os.path.dirname(__file__), 'json_data.json'))
		return ""
	
	def __findpepper(self, url, txt):	
		if re.search("php\?ch=Canale\d{2}", url):
			n = int(url.split("?ch=")[-1].replace("Canale", "")) - 60
			log(n)
			l_static = re.findall('return \s*[\'\"](.+?)[\'\"]\s*\+\s*\(parse', txt)[0]
			log(l_static)
			return f"{l_static}{n}.php" 
		
		elif "php?ch=live" in url:
			n = url.split("?ch=")[-1].replace("live", "")
			#log(n)
			map = eval(re.findall("const m\s*=\s*([\s\S]+?);", txt)[0])
			#log(map)
			#l_static = re.findall('return\s*[\'\"](.+?)[\'\"]\s*\+\s*m', txt)[0]
			#log(l_static)
			#return f"{l_static}{map[n]}"
			return map[n]
		
		elif "php?ch=" in url: #rivedere questo blocco
			token = None
			if url.lower().endswith("extra"):
				token = re.findall("TOKEN\s*=\s*[\'\"](.+?)[\'\"]", txt)[0]
				headers = re.findall("HEADERS\s*=\s*[\'\"](.+?)[\'\"]", txt)[0]
				resp_dic = eval(re.findall("_MAP\s*=\s*([\s\S]*?);", txt)[0])
			else:	
				#temp = "".join([urlparse(webutils.initSites("pepper_base")).scheme, '://', urlparse(webutils.initSites("pepper_base")).netloc, "/", re.findall("fetch\('(.+?)'", txt)[0], str(int(time.time() * 1000))])
				#log(temp)
				#resp_dic = requests.get(temp).text
				#resp_dic = eval(resp_dic.replace('\\', ''))
				resp_dic = eval(re.findall("JSON\s*=\s*([\s\S]*?);", txt)[0].replace('\\', ''))
				resp_dic = {re.sub(r'[^a-z0-9]', '', k.lower()): v for k, v in resp_dic.items()}
				#log(resp_dic)
                		
			ch = url.split("?ch=")[-1].lower()
			#log(ch)
			link = resp_dic[ch]
			extend = re.findall('[\'\"](.+?)#[\'\"]', txt)[0]
			if token:
				l = re.findall("#(.+?)\/\$", txt)[0]
				link = "".join([l, "/", link, "/index.m3u8?token=", token, "&headers=", headers])
			return f"{extend}#{link}"

		return ""

	
	def __findIframes(self, url, links = [], checked = []):
		links = links
		checked = checked
		#try:
		#	self.session.headers.update({'Referer': self.referer_map[url]})
		#except:
		#	pass
		
		if self.player_referer in url: #problem connection: want referer
			self.referer_map[url] = "".join([urlparse(webutils.initSites("calcioga_base")).scheme, '://', urlparse(webutils.initSites("calcioga_base")).netloc])
		
		try:
			s = webutils.Connession()
			s.session.headers.update({'User-Agent': USER_AGENT, 'referer': self.referer_map[url], 'sec-fetch-dest': 'iframe'})
			#log(s.session.headers)
			r = s.get(url, allow_redirects=True, timeout=5)
			#log(r.text)
		except Exception as e:
			log('Liveresolver: Error while trying to access {}: \n\n{}'.format(url,e))
			return []
		
		#----------------- PepperLive code ---------------------
		pepper_check = re.findall("const E([\s\S]*)<\/s", r.text)
		if pepper_check:
			link = self.__findpepper(url, pepper_check[0])
			links.append(link)
			self.referer_map[link] = url
			if "extension://" not in link:
				links += self.__findIframes(link, links, checked)
				checked.append(link)
			return list(set(links))
		#-------------------------------------------------------
		
		if r.status_code == 200:
			urls = re.findall('i?frame\s*.+?src=[\"\']?([^\"\']+)', r.text, flags=re.IGNORECASE)
			#log(urls)
			api = re.findall(">\s+fetch\([\"\'](.+?)[\"\']", r.text)
			if api:
				u = requests.get('https://' + urlparse(url).netloc+'/'+api[0]).json()["url"]
				urls.append(u)
			urls = self.__customUrls(r.text, url, urls)
			
			for u in urls:
				
				if urlparse(u).netloc == '':
					if u.startswith('/'):	
						u = 'http://' + urlparse(url).netloc + '/' + u
					else:
						u = 'http://' + urlparse(url).netloc + '/'.join(urlparse(url).path.split('/')[:-1]) +  '/' + u
				
				if urlparse(u).scheme == '':
					u = 'http://' + u.replace('//','')
	
				u = re.sub(r'\n+', '', u)
				u = re.sub(r'\r+', '', u)
				
				#if not adhosts.isAd(u) and u not in checked and self.__checkUrl(u) and u not in links and len(links)<15:
				#if not adhosts.isAd(u) and u not in checked and u not in links and len(links)<15:
				
				if u not in checked and u not in links and len(links) < 17:
					links.append(u)
					#if 'castmax.me' in u:
					#	self.referer = 'https://castmax.live/'
					#log('referer: %s' % self.referer)
					self.referer_map[u] = url 
					links += self.__findIframes(u, links, checked)
					checked.append(u)
			return list(set(links))
			
		return []
	
	def __customUrls(self, r, ref, urls): 
		fid = re.findall('fid\s*=\s*[\"\']([^\"\']+)[\"\']', r) 
		#m3u8 = re.findall('[\"\'](.+?m3u8.+?)[\"\']', r)
		#log(m3u8)
		#tiny = re.findall('href\s*=\s*[\"\']([^\"\']+).+?class\s*=\s*[\"\']btn\s*btn\-secondary', r)
		unes = re.findall('=\s*[\"\']([^\"\']+)[\"\']+[^\"\']+unescape', r)
		multiline = re.findall('i?frame\s*.+?src=[\"\']?([^\"\']+)', r, flags=re.IGNORECASE | re.DOTALL)
		#telerium = re.findall("'iframe',[\"\'](.+?)[\"\']", r)
		atob = re.findall(r"(?:window.atob\([\"\'](.+?)[\"\']|canal = [\"\'](.+?)[\"\'])", r)
		#src_only = re.findall('(allowfullscreen)*\s*src=[\"\'](.+?)[\"\']\s*(allowfullscreen)*', r)
		#data_src = re.findall('i?frame\s*.+?data\s*.+?src=[\"\']?([^\"\']+)', r, flags=re.IGNORECASE | re.DOTALL)
		#url_in_url = bool(re.search('streamlink\.slice\(4\)', r))
		us = []

		if len(fid) > 0:
			domain = re.findall("text\/javascript' src=[\"\']([^\"\']+).js", r)
			u = ''.join(["https:", domain[0], ".php?player=desktop&live=", fid[0]])
			urls.append(u)

		#if len(m3u8) > 0:
		#	u = m3u8[0].replace("\\", "")
		#	urls.append(u)

		#if len(src_only) > 0:
		#	log(src_only)
		#	urls = [x for t in src_only for x in t]

		if len(atob) > 0:
			u = base64.b64decode(next(x for x in atob[0] if isinstance(x, str) and x.strip())).decode('utf-8')
			urls.append(u)

		#if len(tiny) > 0:
		#	urls.append(tiny[0])
		#	self.referer_map[tiny[0]] = ref

		if len(unes) > 0:
			u = unes[0].replace('@', '%')
			import urllib.parse
			#html = urllib.unquote(u).decode('utf8')
			html = urllib.parse.unquote(u)
			try:
				u = re.findall('i?frame\s*.+?src=[\"\']?([^\"\']+)', html, re.IGNORECASE)[0]
				us.append(u)
				self.referer_map[u] = ref
			except:
				pass
		if len(multiline) > 0:
			for u in multiline:
				us.append(u)
		
		#if len(data_src) > 0:
		#	for u in data_src:
		#		urls.append(u)
		
		#if url_in_url:
		#	u = re.findall('\?.{3}([^$]+)', ref)[0]
		#	self.referer_map[u] = ref
		#	us.append(u)
		#for u in us:
			#if not adhosts.isAd(u) and self.__checkUrl(u) and u not in urls:
		#	if not adhosts.isAd(u) and u not in urls:
		#		urls.append(u)
		return urls
		
	def clearIframes(self, iframe_list, link):
		blacklist = (',', 'adserv', 'javascript', ';', 'ads.com', '.js', 
				'ad4', '()', '.svg', '/https', 'soccer.store', '/\\', "sportsonline", "sportzonline", 
				"premiumtv/t", self.player_referer, "//superiorcrop")
		cleared = []

		for s in iframe_list:
			if not any(b in s for b in blacklist):
				cleared.append(s)

		if not link.endswith(".m3u8") and link in cleared:
			cleared.remove(link)
		return cleared
	
	"""
	def __checkUrl(self, url):
		blacklist = ['chatango', 'adserv', 'live_chat', 'ad4', 'cloudfront', 'image/svg', 'getbanner.php','/ads', 'ads.', 'adskeeper', '.js', '.jpg', '.png', '/adself.', 'min.js',
					'mail.ru']
		return not any(w in url for w in blacklist)
		"""
	
	"""
	def __customUrls(self, r, ref, urls):
		fid = re.findall('fid\s*=\s*[\"\']([^\"\']+)[\"\']', r) 
		m3u8 = re.findall('[\"\'](.+?m3u8.+?)[\"\']', r)
		#tiny = re.findall('href\s*=\s*[\"\']([^\"\']+).+?class\s*=\s*[\"\']btn\s*btn\-secondary', r)
		unes = re.findall('=\s*[\"\']([^\"\']+)[\"\']+[^\"\']+unescape', r)
		multiline = re.findall('i?frame\s*.+?src=[\"\']?([^\"\']+)', r, flags=re.IGNORECASE | re.DOTALL)
		#telerium = re.findall("'iframe',[\"\'](.+?)[\"\']", r)
		#atob = re.findall("window.atob\([\"\'](.+?)[\"\']", r)
		#src_only = re.findall("allowfullscreen=[\s\S]*?src=[\"\'](.+?)[\"\']", r)
		#data_src = re.findall('i?frame\s*.+?data\s*.+?src=[\"\']?([^\"\']+)', r, flags=re.IGNORECASE | re.DOTALL)
		us = []

		if len(fid) > 0:
			domain = re.findall("text\/javascript' src=[\"\']([^\"\']+).js", r)
			u = f"https:{domain[0]}.php?player=desktop&live={fid[0]}"
			urls.append(u)

		#if src_only:
		#	urls.append(src_only[0])

		if len(m3u8) > 0:
			u = m3u8[0].replace("\\", "")
			urls.append(u)

		#if atob:
		#	u = base64.b64decode(atob[0]).decode('utf-8')
		#	urls.append(u)

		#if atob2:
		#	u = base64.b64decode(atob2[0]).decode('utf-8')
		#	urls.append(u)

		#if tiny:
		#	urls.append(tiny[0])
		#	self.referer_map[tiny[0]] = ref

		if len(unes) > 0:
			u = unes[0].replace('@', '%')
			html = unquote(u)
			try:
				u = re.findall('i?frame\s*.+?src=[\"\']?([^\"\']+)', html, re.IGNORECASE)[0]
				us.append(u)
				self.referer_map[u] = ref
			except:
				pass

		if len(multiline) > 0:
			#log(multiline)
			for u in multiline:
				us.append(u)
			
		#if data_src:
		#	for u in data_src:
		#		urls.append(u)
			
		#if url_in_url:
		#	u = re.findall('\?.{3}([^$]+)', ref)[0]
		#	self.referer_map[u] = ref
		#	us.append(u)
		return urls
	"""
	"""
	def clearIframes(self, list):
		chars = [',', 'adserv', 'javascript', ';', 'ads.com', '.js', 'ad4', '()', '.svg', '/https', 'soccer.store', '/\\', self.player_referer]
		list2 = []

		for s in list:
			if all(c not in s for c in chars):
				list2.append(s)
		return list2
"""
'''
class Thread(threading.Thread):
	def __init__(self, func, arg1, arg2, out):
		self.func = func
		self.arg1 = arg1
		self.arg2 = arg2
		self.out = out
		self._return = None
		threading.Thread.__init__(self)

	def run(self):
		try:
			resolved = self.func(self.arg1, self.arg2)
			self.out.append(resolved)
		except Exception as e:
			log("Liveresolver thread error: " + str(e))
			self.out.append(None)
'''
class Thread(threading.Thread):
	def __init__(self, func, url, out):
		self.func = func
		self.url = url
		self.out = out
		self._return = None
		threading.Thread.__init__(self)

	def run(self):
		try:
			resolved = self.func(self.url)
			self.out.append(resolved)
		except Exception as e:
			log("Liveresolver thread error: " + str(e))
			self.out.append(None)
		
		