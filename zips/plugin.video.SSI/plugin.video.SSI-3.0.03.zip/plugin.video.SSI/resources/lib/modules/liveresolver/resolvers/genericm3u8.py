import re, json, base64, math, requests, ast, time

from urllib.parse import urlparse, unquote, parse_qs
from resources.lib.modules.log_utils import log
from resources.lib.modules import constants

class Resolver():
    
    M3U8_RE = re.compile('["\']((?:https?:\/\/|https?:\\\/\\\/)[^"\']+\.m3u8[^"\']*)["\']')
    ECONFIG_RE = re.compile("econfig\s*=\s*['\"](.+?)['\"]")
    STREAMURL_RE = re.compile('streamurl[\s\S]*?(https?[^"\']+\.m3u8)')
    DAMITV = re.compile('fetch\([\'"](.+?)[\'"]\s*\+.*?[\'"](\?t=)')
    DAMI_SESSION = re.compile('fetch\([\'"](.+?)[\'"]')
    #ENDPOINT = re.compile('point:\s*[\'\"](.+?)[\'\"]')
    #SITE = re.compile('action\s*=\s*[\'\"](.+?)[\'\"]')
    ARRAY_OBF = re.compile(
        r'\bvar\s+'
        r'(?P<array_name>_\w+)\s*=\s*(?P<array>\[[\d,\s]+\])\s*,\s*'
        r'(?P<key1_name>_\w+)\s*=\s*(?P<key1>\d+)\s*,\s*'
        r'(?P<key2_name>_\w+)\s*=\s*(?P<key2>\d+)'
        r'.*?'
        r'\(\('
        r'(?P=array_name)\[[^\]]+\]\s*\^\s*(?P=key1_name)'
        r'\)\s*-\s*(?P=key2_name)'
        r'\s*\+\s*(?P<add>\d+)'
        r'\)\s*&\s*(?P<mask>\d+)',
        re.DOTALL
    )
    
    
    
    HEADERS = {
            "User-Agent": constants.USER_AGENT
    }
    
    def __init__(self):
        pass
  
    def decode_econfig(self, input_data):
        if not input_data:
            return None

        order = [2, 0, 3, 1]
        parts_count = 4

        data = base64.b64decode(input_data).decode("utf-8", errors="ignore")
        length = len(data)
        part_size = math.floor(length / parts_count)

        parts = []
        offset = 0

        for _ in range(parts_count):
            parts.append(data[offset:offset + part_size])
            offset += part_size

        decoded_parts = [None] * len(order)

        for i in range(len(order)):
            p = parts[i]
            p = p[:3] + p[4:]
            decoded_parts[order[i]] = base64.b64decode(p).decode("utf-8", errors="ignore")

        merged = "".join(decoded_parts)
        final = base64.b64decode(merged).decode("utf-8", errors="ignore")
        return json.loads(final)
    
    def clear_play_url(self, play):
        
        play_url = play.replace("\\", "").strip()
                
        if play_url.startswith("%3C"):
            return None
                
        if play_url.startswith("//"):
            play_url = "https:" + play_url
                
        if not urlparse(play_url).scheme:
            play_url = "https://" + play_url.replace("://", "")
                
        return play_url   

    def build_headers(self, url):
        host = urlparse(url)
        return {
            "Referer": f"{host.scheme}://{host.netloc}/",
            "Origin": f"{host.scheme}://{host.netloc}",
            "User-Agent": constants.USER_AGENT
        }
    
    def resolve(self, url, html='', referer = None):
        #s = connection.Connession()
        s = requests.Session()
        s.headers.update(self.HEADERS)
        
        if '.m3u8' in url and "&url=" not in url:
            if referer:
                return {'url': url, 'headers': self.build_headers(referer)}
            return {'url': url, 'headers': self.build_headers(url)}
        
        if referer:
            s.headers["Referer"] = referer
            
        try:
            resp = s.get(url)
            #if resp.status_code == 429:
            #    resp = s.get(url)
            
            html = resp.text
            log(html)
        
        except Exception as e:
            log(e)
            return None
        
        url = resp.url
        
        
        
        # ----------- ARRAY_OBF ----------------
        match = self.ARRAY_OBF.search(html, re.DOTALL)
             
        if match:
            array = ast.literal_eval(match.group("array"))
            decoded = ''.join(
                chr(((value ^ int(match.group("key1"))) - int(match.group("key2")) + int(match.group("add"))) & int(match.group("mask")))
                for value in array
            )
            #log(decoded)
            play_url = re.search("(?:url|URL)\s*=\s*[\"'](.+?)[\"']", decoded).group(1)
            play_url = self.clear_play_url(play_url)
            return {'url': play_url, 'headers': self.build_headers(url)}
        #-------------------------------------------------- Recupera correttamente il link ma non riesce a leggerlo inputstream
        
        #---------- DAMITV -----------------
        dami = self.DAMITV.search(html)
        if dami:
            head = {"Referer": url}
            session = self.DAMI_SESSION.findall(html)
            domain = urlparse(url)
            #log(domain)
            sid = s.get(f"{domain.scheme}://{domain.netloc}{session[0]}", headers=head).json()["s"]
            
            time.sleep(2.5)
            
            t = s.get(f"{domain.scheme}://{domain.netloc}{session[1]}{sid}", headers=head).json()["t"]
            
            if "resolve" in domain.query:
                param = parse_qs(domain.query)["resolve"][0]
                stream = s.get(f"{domain.scheme}://{domain.netloc}{session[3]}{param}?t=", headers=head).json()["stream"]
            
            else:
                stream = unquote(parse_qs(domain.query)["url"][0])
            
            #log(stream)
            
            if "&t=" not in stream:
                stream = f"{stream}&t={t}"
            
            #return {'url': stream, 'headers': {"User-Agent": constants.USER_AGENT}}
            return {'url': stream, 'headers': self.build_headers(url)}
        # --------------------------------
        
        #ch = self.ENDPOINT.search(html)
        #if ch:
        #    token = s.post(f"{ch.group(1)}challenge", headers=self.HEADERS).json()
        #    log(token)
        #    log(token["token"])
        #    return
        #    token2 = s.post(f"{ch.group(1)}redeem", headers= self.HEADERS, json={"token": token.strip()}).json()
        #    log(token2)
        #    site = self.SITE.search(html)
        #    log(site)
        #    html = s.post(f"{url}{site}", headers=self.HEADERS, json={"token": token2}).text
        #    log(html)
        #return
        		
        m = self.ECONFIG_RE.search(html)
        if m:
            cfg = self.decode_econfig(m.group(1))
            if cfg and "stream_url" in cfg:
                return {'url': cfg["stream_url"], 'headers': self.build_headers(url)}	

        m = self.M3U8_RE.search(html)
        
        if not m:
            return None
        
        play_url = m.group(1)
        
        play_url = self.clear_play_url(play_url)
        
        """
        if play_url.startswith("%3C"):
            return None
        
        if play_url.startswith("//"):
            play_url = "https:" + play_url
        
        if not urlparse(play_url).scheme:
            play_url = "https://" + play_url.replace("://", "")
        
        """
        if len(play_url) > 60 and "streamurl" in play_url:
            m2 = self.STREAMURL_RE.search(html)
            if m2:
                play_url = m2.group(1)
                
        return {'url': play_url, 'headers': self.build_headers(url)}

