import re
import requests
import json

try:
	from urllib.parse import urlparse
except:
	from urlparse import urlparse  # Python 2

from resources.lib.modules.log_utils import log
from resources.lib.modules import jsunpack
from resources.lib.modules.constants import USER_AGENT

from resources.lib.modules import webutils

class Resolver():

	def __init__(self):
		self.hosts = {}
		self.headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36'}

	#def priority(self):
	#	return 0

	#def isSupported(self, url, html):
	#	return bool(re.search('[\"\']((?:http)?[^\"\']+\.m3u8[^\"\']*)[\"\']', html))

	def resolve(self, url, html='', referer = None):
		if 'm3u8' in url:
			play_url = url
			headers = {'Referer': 'https://'+urlparse(url).netloc+'/', 'Origin': 'https://'+urlparse(url).netloc, "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36"}
			return {'url': play_url, 'headers': headers}
		
		#s = requests.session()
		s = webutils.Connession()
		
		s.session.headers.update(self.headers)
		if referer:
			s.session.headers.update({'Referer': referer})
		try:
			#log(s.session.headers)
			resp = s.get(url)
			#log(resp)
			try:
				url = resp.history[-1].url
			except:
				pass
			html = resp.text
			#log(html)
		
			play_url = re.findall('[\"\']((?:http)?[^\"\']+\.m3u8[^\"\']*)[\"\']', html)
			#log(play_url)
		except Exception as e:
			log(e)
			return None
		
		if len(play_url) == 0:
			return None
		
		if len(play_url[0]) > 60 and "streamurl" in play_url[0]:
			#log("ENTRA")
			play_url = re.findall('streamurl[\s\S]*?(ht(?:http)?[^\"\']+\.m3u8[quot^\"\']*)&', html)

		play_url = play_url[0]
		#log(play_url)
		if play_url.startswith('%3C'):
			return None
		play_url = play_url.replace("\\", "")
		#log(play_url)
		if urlparse(play_url).scheme == '':
			play_url = play_url.replace('://', '')
			play_url = 'http://' + play_url
			play_url = play_url.replace('////','//')
		#log('url referer %s' % url)
		
		headers = {'Referer': 'https://'+urlparse(url).netloc+'/', 'Origin': 'https://'+urlparse(url).netloc, "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36"}
		#headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36", "verifyseek": "false"}
		
		#log("url: %s" % headers)
		#log(s.session.headers)
		#log(s.session.cookies.get_dict())
		return {'url': play_url, 'headers': headers}

