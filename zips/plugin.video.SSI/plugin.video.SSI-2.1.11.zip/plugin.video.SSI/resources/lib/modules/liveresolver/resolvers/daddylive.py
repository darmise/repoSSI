import re, json, base64, requests
from urllib.parse import urlparse, quote_plus
from resources.lib.modules.log_utils import log

class Resolver():

	def __init__(self):
		self.AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36"
		self.headers = {'User-Agent': self.AGENT}

	def resolve(self, url, html='', referer = None):
		s = requests.session()
		s.headers.update(self.headers)
		if referer:
			s.headers.update({'Referer': referer, 'Origin': referer})		
		try:
			resp = s.get(url)
			html = resp.text
			#log(html)
		except Exception as e:
			log(e)
			return None
		
		try:
			session_token_code = re.findall('SESSION_TOKEN\s*=\s*(.+?);', html)[0]
			#log(session_token_code)
			ch_key_code = re.findall('CHANNEL_KEY\s*=\s*(.+?);', html)[0]
			#log(ch_key_code)
			client_token_code = re.findall('CLIENT_TOKEN\s*=\s*btoa*\((.+?)\);', html)[0]
			#log(client_token_code)
			ch_key = re.findall('_0874bb9f\s*=\s*_945f067d\(*\"(.+?)\"', html)[0]
			#log(ch_key)
			#url_temp = ref_base + temp + ch_key
			session_token = re.search("_5d53945ca\s*=\s*\[(.+?)\]", html).group(1).split(",")
			#log(session_token)
			auth_country = re.search("const AUTH_COUNTRY\s*=\s*[\'\"](.+?)[\'\"]", html).group(1)
			#log(auth_country)
			auth_ts = re.search("const AUTH_TS\s*=\s*[\'\"](.+?)[\'\"]", html).group(1)
			auth_expiry = re.search("const AUTH_EXPIRY\s*=\s*[\'\"](.+?)[\'\"]", html).group(1)

			def generate_client_token(channel_key, auth_country, auth_ts, user_a, screen_w, screen_h, timez = "UTC", lan = "en"):
				screen = f"{screen_w}x{screen_h}"
				fingerprint = f"{user_a}|{screen}|{timez}|{lan}"
				sign_data = f"{channel_key}|{auth_country}|{auth_ts}|{user_a}|{fingerprint}"
				token = base64.b64encode(sign_data.encode("utf-8")).decode("utf-8")
				return token

			token_client = generate_client_token(ch_key, auth_country, auth_ts, self.AGENT, 1536, 864, timez="Europe/Rome", lan="it-IT")
			temp = re.findall("fetchWithRetry\(\s*'([^\']*heartbeat)'", html)[0]
			#log(temp)

			headers = {
				"Authorization": f"Bearer {session_token}",
				"X-Channel-Key": f"{ch_key}",
				"X-Client-Token": f"{token_client}",
				"User-Agent": f"{self.AGENT}" #x-key-nonce
			}
			auth = s.get(temp, headers=headers, timeout=10)
			#log(auth.json())
			
			temp2 = re.findall("fetchWithRetry\(\'(.+?)\'", html)[0]
			url_temp2 = temp2 + ch_key
			html2 = s.get(url_temp2, timeout=10).json()
			key = html2["server_key"]
			#log(key)
			domain = re.findall('sk}(.+?)\${sk', html)[0]
			if key == "top1/cdn":
				play_url = f"https://top1.newkso.ru/top1/cdn/{ch_key}/mono.css"
			else: 
				play_url = f"https://{key}{domain}{key}/{ch_key}/mono.css"
			
			header_string = "&".join(["{}={}".format(k, v) for k, v in headers.items()])
			#log(play_url)
			return {'url': play_url, 'headers': header_string, 'license_server': temp}
				
		except: 
			return None
		