import re, json, base64, requests
from urllib.parse import urlparse, quote_plus
from resources.lib.modules.log_utils import log
from resources.lib.modules import webutils

class Resolver():

    def __init__(self):
        self.AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36"
        self.headers = {'User-Agent': self.AGENT}
        self.BASE_API = "https://api.screenify.shop/api"

    def resolve(self, url, html='', referer=None):
        try:
            if "?config" not in url:
                raise ValueError("?config non trovato")
        except ValueError:
            return None
        try:
            config = url.split("?config=")[-1]
            #log(config)
            url_api = f"{self.BASE_API}/embed-configs/public/{config}"
            #log(url_api)
            s = webutils.Connession()
            s.session.headers.update(self.headers)
            if referer:
                s.session.headers.update({'Referer': referer})
            
            resp_api = s.get(url_api).json()
            #log(resp_api)
        
        except:
            return None

        stream_id = resp_api.get("stream")
        active = resp_api.get("isActive")
        relays, token = self.get_relays(url)
        #log(relays)
        #log(token)
        urls = [f"{relay}/stream/{stream_id}/index.m3u8?token={token}" for relay in relays]
        play_url = next((u for u in urls if active), None)
        #log(play_url)
        headers = {'Referer': 'https://'+urlparse(url).netloc+'/', 'Origin': 'https://'+urlparse(url).netloc, "User-Agent": self.AGENT}    
        return {'url': play_url, 'headers': headers}
    
    def get_relays(self, url):
        s = webutils.Connession()
        r = s.get(url).text
        u = "\/_next\/static\/chunks\/app\/embed\/player"
        code = re.findall(f"{u}(.+?).js", r)[0]
        url_js = "".join(['https://', urlparse(url).netloc, u.replace("\\", ""), code, ".js"])
        html = s.get(url_js).text
        #log(html)
        relays = re.findall("_URL\|*\|*[\'\"](.+?)[\'\"]", html)
        token = re.findall("_TOKEN\|*\|*[\'\"](.+?)[\'\"]", html)[0]
        return relays, token     
