import re
import requests
import json
import base64
import math

try:
	from urllib.parse import urlparse
except:
	from urlparse import urlparse  # Python 2

from resources.lib.modules.log_utils import log
from resources.lib.modules import jsunpack
from resources.lib.modules.constants import USER_AGENT

from resources.lib.modules import webutils

class Resolver():

	def __init__(self):
		self.UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36'
		self.headers = {'User-Agent': self.UA}
  
	def decode_econfig(self, input_data):
		if not input_data:
			return None

		order = [2, 0, 3, 1]
		parts_count = 4

		data = base64.b64decode(input_data).decode("utf-8", errors="ignore")
		length = len(data)
		part_size = math.floor(length / parts_count)

		parts = []
		offset = 0

		for _ in range(parts_count):
			parts.append(data[offset:offset + part_size])
			offset += part_size

		decoded_parts = [None] * len(order)

		for i in range(len(order)):
			p = parts[i]
			p = p[:3] + p[4:]
			decoded_parts[order[i]] = base64.b64decode(p).decode("utf-8", errors="ignore")

		merged = "".join(decoded_parts)
		final = base64.b64decode(merged).decode("utf-8", errors="ignore")
		return json.loads(final)

	#def priority(self):
	#	return 0

	#def isSupported(self, url, html):
	#	return bool(re.search('[\"\']((?:http)?[^\"\']+\.m3u8[^\"\']*)[\"\']', html))

	def resolve(self, url, html='', referer = None):
		if 'm3u8' in url:
			play_url = url
			headers = {'Referer': 'https://'+urlparse(url).netloc+'/', 'Origin': 'https://'+urlparse(url).netloc, "User-Agent": self.UA}
			return {'url': play_url, 'headers': headers}
		
		#s = requests.session()
		s = webutils.Connession()
		
		s.session.headers.update(self.headers)
		if referer:
			s.session.headers.update({'Referer': referer})
		try:
			resp = s.get(url)
			if resp.status_code == 429:
				resp = requests.get(url, headers={'User-Agent': self.UA, 'Referer': referer})
			#log(resp)
			try:
				url = resp.history[-1].url
			except:
				pass
			html = resp.text
			#log(html)		
			if "window._econfig" in html:
				config = re.findall("econfig=[\'\"](.+?)[\'\"]", html)[0]
				config_json = self.decode_econfig(config)
				m3u8 = config_json['stream_url']
				headers = {'Referer': 'https://'+urlparse(url).netloc+'/', 'Origin': 'https://'+urlparse(url).netloc, "User-Agent": self.UA}
				return {'url': m3u8, 'headers': headers}	

			else:
				play_url = re.findall('[\"\']((?:http)?[^\"\']+\.m3u8[^\"\']*)[\"\']', html)
				#log(play_url)
		except Exception as e:
			log(e)
			return None
		
		if len(play_url) == 0:
			return None
		
		if len(play_url[0]) > 60 and "streamurl" in play_url[0]:
			play_url = re.findall('streamurl[\s\S]*?(ht(?:http)?[^\"\']+\.m3u8[quot^\"\']*)&', html)

		play_url = play_url[0]
		#log(play_url)
		if play_url.startswith('%3C'):
			return None
		play_url = play_url.replace("\\", "")
		#log(play_url)
		if urlparse(play_url).scheme == '':
			play_url = play_url.replace('://', '')
			play_url = 'http://' + play_url
			play_url = play_url.replace('////','//')
		#log('url referer %s' % url)
		
		headers = {'Referer': 'https://'+urlparse(url).netloc+'/', 'Origin': 'https://'+urlparse(url).netloc, "User-Agent": self.UA}
		return {'url': play_url, 'headers': headers}

