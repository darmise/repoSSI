from resources.lib.modules.addon import Addon
import sys,os,json
import xbmc
import xbmcvfs

from urllib.parse import urlparse, parse_qs, urlencode

import sys
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
from resources.lib.modules import control, cache, constants, webutils
from resources.lib.modules.log_utils import log

addon = Addon('plugin.video.SSI', sys.argv)
addon_handle = int(sys.argv[1])

if not os.path.exists(control.dataPath):
	os.mkdir(control.dataPath)

AddonPath = control.addonPath
IconPath = os.path.join(AddonPath, control.transPath("resources/media/"))
fanart = os.path.join(AddonPath, control.transPath("/fanart.jpg"))

def icon_path(filename):
	if 'http' in filename:
		return filename
	return control.transPath(os.path.join(IconPath, filename))

def menu_sites(category = 'live_sport'):
	sources = os.listdir(AddonPath + '/resources/lib/sources/{}'.format(category))
	for source in sources:
		if '.pyo' not in source and '__init__' not in source and '__pycache__' not in source:
			try:
				source = source.replace('.py','')
				exec("from resources.lib.sources.{} import {}".format(category, source))
				info = eval(source+".info()")
				if info.enabled:
					addon.add_item({'mode': 'open_site', 'category': category, 'site': info.mode}, {'label': info.name, 'title': info.name}, img=icon_path(info.icon), fanart=fanart,is_folder=True)
			except Exception as e:
				log(str(e))
				pass

try:
	from urllib.parse import urlparse, parse_qs
	args = parse_qs(sys.argv[2][1:])
except:
	args = urlparse.parse_qs(sys.argv[2][1:])

mode = args.get('mode', None)
if mode is None:

	ip, localize = webutils.get_ip_information()
	addon.add_item({'mode': 'info'}, {'label': f"[COLOR blue] Indirizzo IP: [B] {ip} - [/B] Paese: [B]{localize}[/B] [/COLOR]", 'title':'Info'}, img=icon_path('info.png'), fanart=fanart,is_folder=True)
	menu_sites()
	#addon.add_item({'mode': 'open_category', 'category':'live_sport'}, {'label': '[COLOR lime] Live Streaming [/COLOR]', 'title':'Live Sport'}, img=icon_path('live_sport.jpg'), fanart=fanart, is_folder=True)
	addon.add_item({'mode': 'tools'}, {'label': '[COLOR lime] Impostazioni [/COLOR]', 'title':'Tools'}, img=icon_path('tools.jpg'), fanart=fanart,is_folder=True)
	webutils.updateJSON() #
	addon.end_of_directory()
	
#for debug purposes
elif mode[0]=='keyboard_open':

	
	keyboard = xbmc.Keyboard('', 'Enter URL:', False)
	keyboard.doModal()
	if keyboard.isConfirmed():
		query = keyboard.getText()
		
		if '.m3u8' in query:
			xbmc.Player().play(query)
		else:
			from resources.lib.modules import liveresolver
			resolved = liveresolver.Liveresolver().resolve(query)
			if resolved:
				if 'plugin://' in resolved['url']:
					xbmc.executebuiltin('RunPlugin({})'.format(resolved['url']))

				else:
					resolved = '{}|{}'.format(resolved['url'], urlencode(resolved['headers']))
					xbmc.Player().play(resolved)

elif mode[0] == 'open_category':
	category = args['category'][0]
	sources = os.listdir(AddonPath + '/resources/lib/sources/{}'.format(category))
	for source in sources:
		if '.pyo' not in source and '__init__' not in source and '__pycache__' not in source:
			try:
				source = source.replace('.py','')
				exec("from resources.lib.sources.{} import {}".format(category, source))
				info = eval(source+".info()")
				if info.enabled:
					addon.add_item({'mode': 'open_site', 'category': category, 'site': info.mode}, {'label': info.name, 'title': info.name}, img=icon_path(info.icon), fanart=fanart,is_folder=True)
			except Exception as e:
				log(str(e))
				pass
	addon.end_of_directory()

	"""
elif mode[0] == 'search':
	category = args['category'][0]

	keyboard = xbmc.Keyboard('', 'Enter search query:', False)
	keyboard.doModal()
	if keyboard.isConfirmed():
		
		query = keyboard.getText()
		xbmc.executebuiltin("Container.Update(%s)"%addon.build_plugin_url({'mode': 'open_search', 'query':query, 'category': category}))
	"""
elif mode[0]=='open_search':
	category = args['category'][0]
	query = args['query'][0]

	sources = os.listdir(AddonPath + '/resources/lib/sources/{}'.format(category))
	for source in sources:
		if '.pyo' not in source and '__init__' not in source and '__pycache__' not in source and '.pyc' not in source:
			try:
				site = source.replace('.py','')
				exec("from resources.lib.sources.{} import {}".format(category, site))
				info = eval(site+".info()")
				srch = False
				try: srch = info.searchable
				except: pass
				if srch:
					s = eval(site+".main()")
					events = s.search(query)
					for event in events:
						try:
							img = icon_path(event[2])
						except:
							img = icon_path(info.icon)
						if not info.multilink:
							addon.add_item({'mode': 'play', 'category': category, 'url': event[0],'title':event[1], 'img': img,'site':site}, {'label': event[1], 'title': event[1].rstrip('[/B]')}, img=img, fanart=fanart, is_folder=False)
						else:
							if (control.setting('link_precheck') == 'false'):
								ctxt = [('Rescrape links', 'RunPlugin(%s)'%addon.build_plugin_url({'mode': 'get_links_refresh', 'url': event[0], 'category': category, 'site':site , 'title':event[1], 'img': img, 'timeout': 'true'}))]
							else:
								ctxt = []
							addon.add_item({'mode': 'get_links', 'url': event[0], 'category': category, 'site':site , 'title':event[1], 'img': img}, {'label': event[1],'title': event[1]}, img=img, fanart=fanart,  is_folder=True)
			except Exception as e:
				log("Error {} - {} - {}".format(category, site, e))
				pass

	addon.end_of_directory()


	

elif mode[0] == 'open_site':
	category = args['category'][0]
	site = args['site'][0]
	try:
		next_page = args['next'][0]
	except:
		next_page = None

	exec("from resources.lib.sources.{} import {}".format(category, site))
	info = eval(site+".info()")
	if not info.categorized:
		if next_page:
			source = eval(site+".main(url=next_page)")
		else:
			source = eval(site+".main()")
		try:
			events = source.events()
		except Exception as e:
			log(e)
			events = []
		for event in events:
			try:
				img = icon_path(event[2])
			except:
				img = icon_path(info.icon)

			if not info.multilink:

				addon.add_item({'mode': 'play', 'url': event[0], 'category': category, 'title':event[1], 'img': img,'site':site}, {'label': event[1], 'title':event[1].rstrip('[/B]')}, img=img, fanart=fanart, is_folder=False)
			else:
				if (control.setting('link_precheck') == 'false'):
					ctxt = [('Rescrape links', 'RunPlugin(%s)'%addon.build_plugin_url({'mode': 'get_links_refresh', 'url': event[0], 'category': category, 'site':site , 'title':event[1], 'img': img, 'timeout': 'true'}))]
				else:
					ctxt = []
				addon.add_item({'mode': 'get_links','site':site, 'category': category, 'url': event[0], 'title':event[1], 'img': img}, {'label': event[1], 'title': event[1]}, img=img, fanart=fanart,is_folder=True)
		if (info.paginated and source.next_page()):
			addon.add_item({'mode': 'open_site', 'site': info.mode, 'category': category, 'next' : source.next_page()}, {'label':'Next Page >>' ,'title': 'Next Page >>'}, img=icon_path(info.icon),  fanart=fanart,is_folder=True)

	else:
		source = eval(site+".main()")
		categories  = source.categories()
		
		for cat in categories:
			try:
				img = icon_path(cat[2])
			except:
				img = icon_path(info.icon)
			addon.add_item({'mode': 'open_site_category', 'url': cat[0], 'category': category, 'site': info.mode}, {'label': cat[1],'title': cat[1]}, img=img, fanart=fanart,is_folder=True)

	addon.end_of_directory()


elif mode[0]=='open_site_category':
	url = args['url'][0]
	site = args['site'][0]
	category = args['category'][0]
	exec("from resources.lib.sources.{} import {}".format(category, site))
	info = eval(site+".info()")
	source = eval(site+".main(url='{}')".format(url))
	try:
		events = source.events(url)
	except Exception as e:
		log(e)
		events = []

	for event in events:
		try:
			img = event[2]

		except:
			img = icon_path(info.icon)

		if not info.multilink:
			addon.add_item({'mode': 'play', 'category': category, 'url': event[0],'title':event[1], 'img': img,'site':site}, {'label': event[1], 'title':event[1].rstrip('[/B]')}, img=img, fanart=fanart, is_folder=False)
		else:
			if (control.setting('link_precheck') == 'false'):
				ctxt = [('Rescrape links', 'RunPlugin(%s)'%addon.build_plugin_url({'mode': 'get_links_refresh', 'url': event[0], 'category': category, 'site':site , 'title':event[1], 'img': img, 'timeout': 'true'}))]
			else:
				ctxt = []
			addon.add_item({'mode': 'get_links', 'url': event[0], 'category': category, 'site':site , 'title':event[1], 'img': img}, {'label':event[1] ,'title': event[1]}, img=img, fanart=fanart,contextmenu_items=ctxt, is_folder=True)
	
	if (info.paginated and source.next_page()):
		addon.add_item({'mode': 'open_site_category', 'category': category, 'site': info.mode, 'url': source.next_page()}, {'label': 'Next Page >>' ,'title': 'Next Page >>'}, img=icon_path(info.icon), fanart=fanart,is_folder=True)
	
	addon.end_of_directory()

elif mode[0] == 'refresh_links':
	url = args['url'][0]
	site = args['site'][0]
	category = args['category'][0]
	
	exec("from resources.lib.sources.{} import {}".format(category, site))
	info = eval(site+".info()")
	source = eval(site+".main()")
	try:
		cache.remove(source._links, url)
	except:
		pass
	xbmc.executebuiltin("Container.Refresh()")

elif mode[0]=='get_links':
	
	url = args['url'][0]
	title = args['title'][0]
	site = args['site'][0]
	category = args['category'][0]
	img = args['img'][0]
	
	exec("from resources.lib.sources.{} import {}".format(category, site))
	info = eval(site+".info()")
	source = eval(site+".main()")
	try:
		events = source.links(url)
	except:
		events = []
	
	for event in events:
		if (control.setting('link_precheck') == 'false'):
				ctxt = [('Rescrape links','RunPlugin(%s)'%addon.build_plugin_url({'mode': 'refresh_links', 'url': url, 'category': category, 'site':site}))]
		else:
			ctxt = []
		addon.add_item({'mode': 'play', 'url': event[0],'title':title, 'img': img, 'category': category, 'site':site}, {'label': event[1], 'title':title.rstrip('[/B]')}, img=img, fanart=fanart,contextmenu_items=ctxt, is_folder=False)
	if len(events) == 0:
		try: 
			a = hasattr(site, _links)
			addon.add_item({'mode': 'refresh_links', 'url': url, 'category': category, 'site':site}, {'label': 'Rescrape links', 'title': 'Rescrape links', 'img':img})
		except:
			pass
	addon.end_of_directory()
	

elif mode[0] == 'play':
	url = args['url'][0]
	title = args['title'][0]
	category = args['category'][0]
	img = args['img'][0]
	site = args['site'][0]
	
	exec("from resources.lib.sources.{} import {}".format(category, site))
	source = eval(site+'.main()')
	enc = False
	try:
		resolved, enc = source.resolve(url)
	except:
		resolved = source.resolve(url)
	#log("resolved %s" % resolved)
	if resolved:
		
		if 'm3u8' in resolved:
			li = xbmcgui.ListItem(title, path=resolved)
    
			li.setArt({'thumb': img, 'icon': img, 'poster': img})
			li.setProperty('inputstream', 'inputstream.ffmpegdirect')
			li.setMimeType('application/vnd.apple.mpegurl')
			li.setProperty('inputstream.ffmpegdirect.is_realtime_stream', 'true')
			li.setProperty('inputstream.ffmpegdirect.manifest_type', 'hls')
			li.setProperty('inputstream.ffmpegdirect.stream_mode', 'live')

			li.setContentLookup(False)
			li.setProperty("IsPlayable", 'true')
			xbmcplugin.setResolvedUrl(handle=int(sys.argv[1]), succeeded=True, listitem=li)
			
			
		elif '..css' in resolved["url"]: # NON FUNZIONANTE
			li = xbmcgui.ListItem(title, path=resolved["url"])
			li.setMimeType("application/vnd.apple.mpegurl")
			li.setContentLookup(False)
			li.setProperty("IsPlayable", "true")

			li.setProperty("inputstream", "inputstream.adaptive")
			li.setProperty("inputstream.adaptive.manifest_type", "hls")

			headers = resolved["headers"]
			url_server = resolved["license_server"]
			
			li.setProperty("inputstream.adaptive.license_type", "com.widevine.alpha")
			li.setProperty("inputstream.adaptive.license_key", url_server + "|" + headers + "|R{SSM}|")
			xbmcplugin.setResolvedUrl(handle=int(sys.argv[1]), succeeded=True, listitem=li)
		
		else: 
			li = xbmcgui.ListItem(title, path=resolved['url'], offscreen=True)
			li.setArt({'thumb': img})
			li.setMimeType('application/dash+xml')
			li.setContentLookup(False)
					
			li.setProperty('inputstream', 'inputstream.adaptive')
			li.setProperty("inputstream.adaptive.manifest_type", "mpd")

			if resolved.get('clearkeys'):
				"""
				if resolved['clearkeys'] == 'widevine':
					log("TESTIAMO")
					li.setProperty('inputstream.adaptive.license_type', 'com.widevine.alpha')
					li.setProperty('inputstream.adaptive.license_key', 'https://vdp654rf.anycast.nagra.com/VDP654RF/prls/contentlicenseservice/v1/licenses|Content-Type=application/octet-stream&Origin=https://tv.vodafone.pt&Referer=https://tv.vodafone.pt/|R{SSM}|')
				
				else:"""	
				drm = "".join(['org.w3.clearkey', resolved['clearkeys']])
				li.setProperty('inputstream.adaptive.drm_legacy', drm)

			xbmcplugin.setResolvedUrl(handle=int(sys.argv[1]), succeeded=True, listitem=li)
			
########################################################################################################################################################################################################
########################################################################################################################################################################################################
########################################################################################################################################################################################################
####
####______________________________________________________________________________________________TOOLS_________________________________________________________________________________________________
####
########################################################################################################################################################################################################
########################################################################################################################################################################################################
########################################################################################################################################################################################################



elif mode[0]=='tools':
	addon.add_item({'mode': 'settings'}, {'label':'[COLOR lime] Configura Addon [/COLOR]', 'title':'Settings'}, img=icon_path('tools.jpg'), fanart=fanart,is_folder=True)
	#addon.add_item({'mode': 'set_tz'}, {'label': 'Set Timezone: [B]{}[/B]'.format(constants.get_zone(int(control.setting('timezone_new'))))}, img=icon_path('tools.jpg'), fanart=fanart,is_folder=True)
	#addon.add_item({'mode': 'keyboard_open'}, {'label':'Open URL', 'title':'Open URL'}, img=icon_path('tools.jpg'), fanart=fanart,is_folder=True)
	addon.add_item({'mode': 'clear_cache'}, {'label':'[COLOR lime] Pulisci Cache [/COLOR]', 'title':'Clear addon cache'}, img=icon_path('tools.jpg'), fanart=fanart,is_folder=True)
	addon.add_item({'mode': 'clear_json'}, {'label':'[COLOR lime] Pulisci JSON [/COLOR]', 'title':'Clear addon json'}, img=icon_path('tools.jpg'), fanart=fanart,is_folder=True)
	
	addon.end_of_directory()

elif mode[0]=='clear_cache':
	from resources.lib.modules import cache
	cache.clear()


elif mode[0]=='settings':
	from resources.lib.modules import control
	control.openSettings()

elif mode[0]=='clear_json':
	from resources.lib.modules import webutils
	webutils.clearJSON()	
# add clear json



##################################################################################################################################
##################################################################################################################################

elif mode[0]=='reddit':
	from resources.lib.modules import subreddits
	items = subreddits.get_subreddits()
	for item in items:

		delete = addon.build_plugin_url({'mode':'delete_subreddit','reddit':item})
		context = [('Remove subreddit','Container.Update(%s)'%delete)]
		addon.add_item({'mode': 'open_subreddit', 'reddit': item}, {'title': item}, img=icon_path('reddit.jpg'), fanart=fanart,contextmenu_items=context,is_folder=True)

	addon.add_item({'mode': 'add_subreddit'}, {'title': '[B][COLOR green]Add a subreddit[/COLOR][/B]'}, img=icon_path('reddit.jpg'), fanart=fanart)    
	addon.end_of_directory()
elif mode[0]=='add_subreddit':
	from resources.lib.modules import subreddits
	subreddits.add_subreddit()
	control.refresh()

elif mode[0]=='delete_subreddit':
	reddit = args['reddit'][0]
	from resources.lib.modules import subreddits
	subreddits.remove_subreddit(reddit)
	control.refresh()

elif mode[0]=='open_subreddit':
	reddit = args['reddit'][0]
	from resources.lib.modules import subreddits
	items = subreddits.events(reddit)
	for item in items:
		addon.add_item({'mode': 'open_subreddit_event', 'url': item[0]}, {'title': item[1]}, img=icon_path('reddit.jpg'), fanart=fanart,is_folder=True)
	addon.end_of_directory()

elif mode[0]=='open_subreddit_event':
	url = args['url'][0]
	from resources.lib.modules import subreddits
	items = subreddits.event_links(url)
	for event in items:
		browser = 'plugin://plugin.program.chrome.launcher/?url=%s&mode=showSite&stopPlayback=no'%(event[0])


		context = [('Open in browser','Container.Update(%s)'%browser)]

		addon.add_video_item({'mode': 'play', 'url': event[0],'title':event[1], 'img': icon_path('reddit.jpg')}, {'title': event[1]}, img=icon_path('reddit.jpg'), fanart=fanart, contextmenu_items=context)
	addon.end_of_directory()

