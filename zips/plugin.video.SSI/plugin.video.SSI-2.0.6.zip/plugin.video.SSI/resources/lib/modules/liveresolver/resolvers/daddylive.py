import re, json, base64, requests
from urllib.parse import urlparse, quote_plus
from resources.lib.modules.log_utils import log

class Resolver():

	def __init__(self):
		self.AGENT = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36"
		self.headers = {'User-Agent': self.AGENT}

	def resolve(self, url, html='', referer = None):
		s = requests.session()
		s.headers.update(self.headers)
		if referer:
			s.headers.update({'Referer': referer, 'Origin': referer})		
		try:
			resp = s.get(url)
			html = resp.text
			#log(html)
		except Exception as e:
			log(e)
			return None
		
		try:
			ref_base = urlparse(url).scheme + '://' + urlparse(url).netloc
			ref = quote_plus(ref_base)
			temp = re.findall("fetchWithRetry\(\s*'([^\']*)'", html)[0]
			#log(temp)
			ch_key = re.findall('CHANNEL_KEY\s?=\s?"([^"]*)"', html)[0]
			#log(ch_key)
			#url_temp = ref_base + temp + ch_key
			
			auth_token = re.search("const AUTH_TOKEN\s*=\s*[\'\"](.+?)[\'\"]", html).group(1)
			auth_country = re.search("const AUTH_COUNTRY\s*=\s*[\'\"](.+?)[\'\"]", html).group(1)
			auth_ts = re.search("const AUTH_TS\s*=\s*[\'\"](.+?)[\'\"]", html).group(1)
			auth_expiry = re.search("const AUTH_EXPIRY\s*=\s*[\'\"](.+?)[\'\"]", html).group(1)
			
			json_data = {"channelKey": ch_key,
				        "country": auth_country,
						"timestamp": auth_ts,
						"expiry": auth_expiry,
						"token": auth_token
					}
			
			auth = s.post(temp, data=json_data, headers={"Referer": url, "Origin": url})
			log(auth.json())
			temp2 = re.findall("fetchWithRetry\(\'\/(.+?)\'", html)[0]
			url_temp2 = ref_base + '/' + temp2 + ch_key
			html2 = s.get(url_temp2, timeout=10).json()
			key = html2["server_key"]
			domain = re.findall('sk}(.+?)\${sk', html)[0]
			if key == "top1/cdn":
				play_url = f"https://top1.newkso.ru/top1/cdn/{ch_key}/mono.m3u8"
			else: 
				play_url = f"https://{key}{domain}{key}/{ch_key}/mono.m3u8"
			headers = 'Referer={}/&Origin={}&Connection=Keep-Alive&User-Agent={}'.format(ref, ref, quote_plus(self.AGENT))
			return {'url': play_url, 'headers': headers}
				
		except: 
			return None
		