# -*- coding: UTF-8 -*-
from os import link
from resources.lib.modules import  webutils, control, cache, linkSearch, constants
from resources.lib.modules.log_utils import log
import re, xbmcgui, requests
try:
	from urllib.parse import urlencode
except:
	from urllib import urlencode

class info():
	def __init__(self, url= ''):
		self.mode = 'projectlive'
		self.name = '[COLOR orange][B] Projectlive [/B][/COLOR]'
		self.icon = 'https://ec.europa.eu/eurostat/documents/6921402/9104237/Shutterstock_Lisa_Kolbasa.png/f988f8b6-4138-4a91-9761-885bacab0ce2?t=1533725002000'
		#self.enabled = control.setting(self.mode) == 'true'
		self.enabled = False
		self.categorized = False
		self.paginated = False
		self.multilink = False #false riproduce subito non vuole links

class main():
	
	def __init__(self):
		self.base = control.setting('project_base')


	def events(self):
		#tomorrow
		from datetime import timedelta, date
		oggi = date.today().strftime("%d/%m")
		domani = (date.today() + timedelta(days=1)).strftime("%d/%m")
		#log('today: %s' % oggi)
		#log('tow: %s' % domani)
		html_full = requests.get(self.base).text 
		#log('html: %s' % html_full)
		index = html_full.find(oggi)
		index2 = html_full.find(domani)
		indextelegram = html_full.find('<h2>telegram</h2>')
		if indextelegram == -1:
			indextelegram = index
		html_partial = html_full[indextelegram:index2] #solo eventi giorno corrente
		#log('html partial: %s' % html_partial)
		#soup = webutils.bs(res)
		#events = []
		#events = soup.findAll('div', {'class': 'kode_ticket_text'})
		#events = re.findall('<div class="kode_ticket_text">\s+<h6>(.+?)<\/h6>\s+<div class="ticket_title">\s+<h2>(.+?)<\/h2>\s+<span>VS<\/span>\s+<h2>(.+?)<\/h2>\s+<\/div>\s+<p>(.+?)<\/p>\s+<\/div>', res)
		events = re.findall('<li>\s+<div class="kode_ticket_text">([\s\S]*?)<p>(.+?)<\/p>\s+<\/div>\s+<div class="ticket_btn">\s+([\s\S]*?)\s+<\/div>\s+', html_partial)
		#events2 = re.findall('<h6>(.+?)<\/h6>\s+<div class="ticket_title">\s+<h2>(.+?)<\/h2>\s+<\/div>\s+<p>(.+?)<\/p>\s+<\/div>\s+<div class="ticket_btn">\s+([\s\S]*?)\s+<\/div>', html_partial)
		#events2 = re.findall('<h6>(.+?)<\/h6>\s+<div class="ticket_title">([\s\S]*?)\s+<div class="ticket_btn">\s+([\s\S]*?)\s+<\/div>', html_partial)
		#log('events  %s' % events)
		#log('events2  %s' % events2)
		#events = tuple(events)
		#events2 = tuple(events2)
		events = self.__prepare_events(events)
		return events

	def __prepare_events(self,events):
		new=[]
		
		for ev in events:
			evento = ''
			time = ev[1]
			span = re.findall('\s+<span>(.+?)<\/span>\s+', ev[0])
			if not span:
				ev_list = re.findall('<h2>(.+?)<\/h2>', ev[0])
				evento = ev_list[0]
				#log('evento %s' % evento)
			
			else:
				ev_list = re.findall('<h2>(.+?)<\/h2>\s+<span>(.+?)<\/span>\s+<h2>(.+?)<\/h2>', ev[0])
				#log('eventi lista2 %s' % ev_list2)
				evento = ev_list[0][0] + ' ' + ev_list[0][1] + ' ' + ev_list[0][2]	
			url = re.findall('href=[\"\'](.+?)[\"\']target="_blank">(.+?)<\/a>', ev[2])
			title = u'(%s) [COLOR yellow][B] %s [/B][/COLOR] '% (time, evento)  
			new.append((url, title))	

		return new	
	
	def resolve(self,url):
		from resources.lib.modules import liveresolver
		#from datetime import timedelta, date
		#oggi = date.today().strftime("%d/%m")
		#domani = (date.today() + timedelta(days=1)).strftime("%d/%m")
		#html_full = requests.get(self.base).text 
		#index = html_full.find(oggi)
		#index2 = html_full.find(domani)
		#html_partial = html_full[index:index2] #solo eventi giorno corrente
		#events = re.findall('<h6>(.+?)<\/h6>\s+<div class="ticket_title">([\s\S]*?)<p>(.+?)<\/p>\s+<\/div>\s+<div class="ticket_btn">\s+([\s\S]*?)\s+<\/div>', html_partial)
		
		#log('url resolve: %s' % url)
		dialog = xbmcgui.Dialog()
		streamstemp = url[1:-1]
		streams = list(streamstemp.split(','))
		#log('streams %s' % streams)
		#lst =['test']
		lst = [streams[i][2:-2] for i in range(1, len(streams), 2)]
		streams2 = [streams[y][2:-1] for y in range(0, len(streams), 2)]
		#log('lista %s ' % lst)
		index = dialog.select("Seleziona stream", lst)
		#log('indice %s' % index)
		final = ''
		if index != -1:
			if index == 0:
				final =	's'+ streams2[index][1:]
			else:	
				final = streams2[index][1:]
		#final.replace("'", "") 
		#link = self.base + streams[index][0]
		#link = 'https://serieahouse.xyz/player.php?id=g0gzewyzq0oof4'
		link = self.base + final
		#log('link: %s' % link)
		d = liveresolver.Liveresolver().resolve(link)
		if d:
			#if d['url'].startswith('plugin://'):
			#	return d['url']
			return '{}|{}'.format(d['url'], urlencode(d['headers'])), False
		return link, True