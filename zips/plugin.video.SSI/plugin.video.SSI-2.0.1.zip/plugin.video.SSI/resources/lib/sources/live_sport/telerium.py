# -*- coding: UTF-8 -*-
from os import link
from resources.lib.modules import  webutils, control, cache, linkSearch, constants
from resources.lib.modules.log_utils import log
import re
import requests
try:
	from urllib.parse import urlencode
except:
	from urllib import urlencode

class info():
	def __init__(self, url= ''):
		self.mode = 'telerium'
		self.name = '[COLOR blue][B] Telerium [/B][/COLOR]'
		self.icon = 'https://media.istockphoto.com/vectors/soccer-ball-icon-the-ball-for-the-game-of-football-in-a-simple-style-vector-id1222920902?b=1&k=20&m=1222920902&s=170667a&w=0&h=r3bf7ecO3-srCb6xdy2Qp2lSvpAqIj8-w0wPjW6mXRQ='
		self.enabled = control.setting("tel") == 'true'
		#self.enabled = True
		self.categorized = False
		self.paginated = False
		self.multilink = False

class main():
	
	def __init__(self):
		self.base = control.setting('telerium_base')
	
	def events(self):
		headers = {'User-Agent': constants.USER_AGENT, 'referer': self.base}
		html = requests.get(self.base, headers=headers).text
		#log('html %s' % html)
		events = re.findall('"><\/span><\/td><td>(.+?)<a target="_blank" href=[\"\'](.+?)[\"\']><b>(.+?)<\/b>[\s\S]*?">(.+?)<\/span><\/td><td><b', html)
		#log('ERR: %s' % events)
		events = tuple(events)
		events = self.__prepare_events(events)
		#log('eventss: %s' % events)
		return events

	def __prepare_events(self,events):
		new = []
		#new.append(('','[COLOR lime][B] EVENTI OGGI: [/B][/COLOR]', info().icon))
		for e in events: 
			league = e[0]
			url = self.base + e[1][1:]
			match = e[2]
			#log('url %s' % url)
			language = e[3]
			title = u'[COLOR lime] %s [/COLOR] [COLOR yellow][B] %s [/B][/COLOR] - (%s)' % (league, match, language)
			#title = title.encode('utf-8')
			new.append((url,title, 'https://thumbs.dreamstime.com/b/sport-icon-game-177886471.jpg'))
				
		return new 

	def resolve(self,url):
		from resources.lib.modules import liveresolver
		#log("url: %s" % url)
		
		d = liveresolver.Liveresolver().resolve(url)
		if d:
			#if d['url'].startswith('plugin://'):
			#	return d['url']
			if "Referer=" in d['headers']:
				return '{}|{}'.format(d['url'], d['headers']), False
			return '{}|{}'.format(d['url'], urlencode(d['headers'])), False
		return url, True