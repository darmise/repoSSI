# -*- coding: UTF-8 -*-
from os import link
from resources.lib.modules import  webutils, control, cache, linkSearch, constants
from resources.lib.modules.log_utils import log
import re, xbmcgui, requests
from resources.lib.modules import liveresolver

try:
	from urllib.parse import urlencode, quote_plus, unquote_plus
except:
	from urllib import urlencode, quote_plus, unquote_plus


class info():
	def __init__(self, url= ''):
		self.mode = 'pepperlive'
		self.name = '[COLOR red][B] Pepperlive [/B][/COLOR]'
		self.icon = 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSo7Qs9M1kzZ0I8fHHG2_BQEFeCCf2Q3v1kkw&s'
		self.enabled = control.setting("pep") == 'true'
		#self.enabled = True
		self.categorized = False
		self.paginated = False
		self.multilink = False #false riproduce subito non vuole links

class main():
	
	def __init__(self):
		self.base = webutils.initSites('pepper_base')

	def events(self):
		html_full = requests.get(self.base).text
		#log(html_full)
		events = re.findall('kode_ticket_te([\s\S]*?)>\s+<\/li>', html_full)
		#log("events %s" % events)
		events = self.__prepare_events(events)
		return events

	def __prepare_events(self,events):
		new=[]
		#new.append(('', '[COLOR red][B] - Info: visibili sono gli eventi europei ed italiani. [/B][/COLOR]'))
		for e in events:
			
			multiple = re.findall('xt">([\s\S]*?)<p>(.+?)<\/p>\s+<\/div>\s+<div class="ticket_btn">\s+([\s\S]*?)<\/div', e)
			#log("multiple %s" % multiple)
			for mu in multiple:
				evento = ''
				time = mu[1]
				#log("time %s" % time)
				#log("m0 %s" % mu[0])
				ev_list = re.findall('\W*(h2)\W*(.+?)\W*(h2)\W*[\s\S]*?\W*(h2)\W*(.+?)\W*(h2)\W*', mu[0])
				#log('eventi lista2 %s' % ev_list)
				evento = ev_list[0][1] + ' - ' + ev_list[0][4]	
				#log(evento)
				url = re.findall('href=[\"\'](.+?)[\"\']target="_blank">(.+?)<\/a>', mu[2])
				#log("url %s" % url)
				title = u'(%s) [COLOR yellow][B] %s [/B][/COLOR]'% (time, evento)  
				new.append((url, title))
		
		return new
	
			
	
	def resolve(self,url):		
		#log('url resolve: %s' % url)
		dialog = xbmcgui.Dialog()
		streamstemp = url[1:-1]
		#log(streamstemp)
		streams = list(streamstemp.split(','))
		#log('streams %s' % streams)
		lst = [streams[i][2:-2] for i in range(1, len(streams), 2)]
		name = ['Link %s' % t for t in range(1, (len(lst)+1))]
		#lst = [('Link %s' % i)  for i in range(1, len(streams))]
		streams2 = [streams[y][2:-1] for y in range(0, len(streams), 2)]
		#log('lista %s ' % lst)
		index = dialog.select("Seleziona stream", name)
		final = ''
		if index != -1:
			if index == 0:
				final =	streams2[index]
			else:	
				final = streams2[index][1:]
		#final.replace("'", "") 
		#link = self.base + streams[index][0]
		link = self.base + final
		d = liveresolver.Liveresolver().resolve(link)
		#log("dopo resolved %s" % d)
		if d:
			if ".mpd" in d['url']:
				return d, False
			
			if "Referer=" in d['headers']:
				return '{}|{}'.format(d['url'], d['headers']), False
			#elif "mpd" in d['url']:
			#	return '{}|{}'.format(d['url'], d['headers']), False
			return '{}|{}'.format(d['url'], urlencode(d['headers'])), False
		return link, True
		
		
		 
	

