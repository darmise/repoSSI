import re
import requests
import base64
import json

try:
	from urllib.parse import urlparse
except:
	from urlparse import urlparse  # Python 2

from resources.lib.modules.log_utils import log
from resources.lib.modules import jsunpack


class Resolver():

	def __init__(self):
		self.hosts = {}
		self.headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36', 'Cache-control': 'no-cache'}

	def resolve(self, url, html='', referer = None):
		
		referer = referer.replace('http://tutele1.net/', 'https://tutlehd.xyz/')
		s = requests.session()
		s.headers.update({'Referer': referer})
		
		resp = s.get(url, timeout=3).text
		
		try:
			auth = re.findall('"auth":"(.*)","do', resp)[0]
			base_64 = re.findall("value='(.*)' type", resp)[0]
			play_url = base64.b64decode(base_64).decode('utf-8')
			new_url =url+'https%3A%2F%2Fnopay2.info%2F'
			he = {'Referer': new_url, 'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36',  'Origin': 'https://'+ urlparse(url).netloc, 'Xauth': auth}
			return {'url': play_url, 'headers': he}
		except:
			return None	