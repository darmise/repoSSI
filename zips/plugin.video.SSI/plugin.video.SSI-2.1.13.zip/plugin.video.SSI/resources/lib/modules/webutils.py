# -*- coding: utf-8 -*-
try:
	from BeautifulSoup import BeautifulSoup as bss
except:
	from bs4 import BeautifulSoup as bss
try:
	import urllib2
except:
	import urllib.request as urllib2
	
import urllib
from resources.lib.modules import control, constants
import re,sys, requests, os, json
from random import randint
from resources.lib.modules.log_utils import log

#def get_soup(url):
#	return bs(read_url(url))

def get_ip_information():
   
    with urllib.request.urlopen("https://ipwho.is/", timeout=5) as response:
        res = response.read().decode().strip()
        res = json.loads(res)
        ip = res["ip"]
        localize = res["country"]
    return ip, localize 

def downloadProxy(): 
    resp = requests.get(constants.GIMMEPROXY_API_URL)
    if resp.status_code == 200:        
        data = resp.json()        
        proxy = data.get("curl")
    return proxy

def bs(html):
	return bss(html, "html.parser")

def remove_tags(text):
	TAG_RE = re.compile(r'<[^>]+>')
	return TAG_RE.sub('', text)

def normal(string):
    string=string.replace('Š','S').replace('Ž','Z').replace('Č','C').replace('Ć','C').replace('Đ','D')
    return string.replace('š','s').replace('ž','z').replace('č','c').replace('ć','c').replace('đ','d')

def show_text(heading,anounce):
    class TextBox():

            """Thanks to BSTRDMKR for this code:)"""
            WINDOW=10147; CONTROL_LABEL=1; CONTROL_TEXTBOX=5 # constants
            def __init__(self,*args,**kwargs):
                xbmc.executebuiltin("ActivateWindow(%d)" % (self.WINDOW,)) # activate the text viewer window
                self.win=xbmcgui.Window(self.WINDOW) # get window
                xbmc.sleep(500) # give window time to initialize
                self.setControls()
            def setControls(self):
                self.win.getControl(self.CONTROL_LABEL).setLabel(heading) # set heading
                try: f=open(anounce); text=f.read()
                except: text=anounce
                self.win.getControl(self.CONTROL_TEXTBOX).setText(text); return
    TextBox()

def adfly(url):
    import re
    import urllib2
    import httplib
    from socket import timeout
    import base64
    
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req, timeout=5)
    html = response.read()
    response.close()
    ysmm = re.findall("var ysmm =\s*[\"\']([^\"\']+)[\"\']", html)[0]
    left = ''
    right = ''
    for c in [ysmm[i:i+2] for i in range(0, len(ysmm), 2)]:
        left += c[0]
        right = c[1] + right
    decoded_uri = base64.b64decode(left.encode() + right.encode())[2:].decode()
    if re.search(r'go\.php\?u\=', decoded_uri):
        decoded_uri = base64.b64decode(re.sub(r'(.*?)u=', '', decoded_uri)).decode()

    return decoded_uri

def remove_referer(url):
    return re.sub("referer=.+?(?:&|$)","",url).rstrip('?').rstrip('&')


def updateJSON():    
    if control.setting('siti') == 'true':    
        try:
            res = requests.get(constants.SITES_AUTO)
            log(res)
        except: 
            log("Stop")
            control.infoDialog("Sites update: Connection error")
        if res.status_code == 200:
            res_j = res.json()      
            saveJSON(res_j, "".join([os.path.dirname(os.path.abspath(__file__)), "\sites.json"]))
            control.infoDialog(f"Last update sites: {res_j['date']}")        
        
def initSites(name_site): 
    path = "".join([os.path.dirname(os.path.abspath(__file__)), "\sites.json"])
    if control.setting("siti") == "true":
        #json_sites = requests.get(constants.SITES_AUTO).json()
        json_sites = accessJSON(path)
        json_list = json_sites['sites']
        for site in json_list:
            if site['name'] == name_site:
                url = site['url']    
    else: url = control.setting(name_site)	
    return url

def accessJSON(name):
	with open(name, 'r') as file:
		return json.load(file)
	
def saveJSON(lista, name):
    with open(name, "w") as out:
	    json.dump(lista, out)
		
def clearJSON():
	em = []
	saveJSON(em, os.path.join(os.path.dirname(__file__), 'liveresolver\json_data.json'))
	control.infoDialog("JSON pulito!!")       
     
class Connession:
    def __init__(self):
        self.session = requests.Session()

    def get(self, url, **kwargs):
        return self.session.get(url, **kwargs)

    def post(self, url, **kwargs):
        return self.session.post(url, **kwargs)
        
