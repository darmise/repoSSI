# -*- coding: UTF-8 -*-
from os import link
from resources.lib.modules import  webutils, control, cache, linkSearch, constants
from resources.lib.modules.log_utils import log
import re, xbmcgui, requests
from resources.lib.modules import liveresolver
from resources.lib.modules import constants

# ------------------------ CLOUDSCRAPER -------------------
import sys
import os
import xbmcaddon

addon = xbmcaddon.Addon('script.module.cloudscraper')
path = addon.getAddonInfo('path')

sys.path.append(os.path.join(path, 'lib'))
from cloudscraper2 import CloudScraper
#---------------------------------------------------------

try:
	from urllib.parse import urlencode, quote_plus, unquote_plus
except:
	from urllib import urlencode, quote_plus, unquote_plus

class info():
	def __init__(self, url= ''):
		self.mode = 'pepperlive'
		self.name = '[COLOR red][B] Pepper[COLOR yellow][B] Live [/B][/COLOR]'
		self.icon = "".join([webutils.initSites('pepper_base'), 'logo_pepper.png'])
		self.enabled = control.setting("pep") == 'true'
		#self.enabled = True
		self.categorized = False
		self.paginated = False
		self.multilink = False #false riproduce subito non vuole links

class main():
	
	def __init__(self):
		self.base = webutils.initSites('pepper_base')
		self.ua = constants.USER_AGENT

	def events(self):
		scraper = CloudScraper.create_scraper()
		scraper.headers.update({'User-Agent': self.ua})
		cookies = scraper.get(self.base).cookies.get_dict()
		html_full = requests.get(self.base, cookies=cookies).text
		#log(html_full)
		events = re.findall('<span class="category-label">([^<]*)<\/span>([\s\S]*?)(?=<span class="category-label">|<div class="date-header">|<\/main>|$)', html_full)
		#log("events %s" % events) #succ: <\/([\s\S]*?)teams-box">([\s\S]*?)btn-group">([\s\S]*?)<\/div> 
		events = self.__prepare_events(events)
		return events

	def __prepare_events(self,events):
		new=[]
		#new.append(('', '[COLOR red][B] - Info: visibili sono gli eventi europei ed italiani. [/B][/COLOR]'))
		for e in events:
			league = e[0]
			#log(league)
			multiple = re.findall('time-box"([\s\S]*?)teams-box"([\s\S]*?)btn-group"([\s\S]*?)<\/div', e[1])
			#log("multiple %s" % multiple)
			for mu in multiple:
				live = re.findall('live-badge">(.+?)<\/', mu[0])
				hour = re.findall('ora-txt" [\(style="color:var\(--live\)"]*>(.+?)<\/span>', mu[0])[0]
				if len(live) > 0:
					time = "[COLOR red] Live [/COLOR]"	 
				else: time = hour
				
				event = ""
				if "vs-txt" in mu[1]:
					teams = re.findall("\s+(.+?)<spa[\s\S]*an>(.+?)\s*<", mu[1])[0]
					#log(teams) 
					event = f"{teams[0]} - {teams[1]}"
					#log(event)
				else: event = re.findall('\\n\s*(.+?)<\/', mu[1])[0].strip()
			
				url = re.findall('href=[\"\'](.+?)[\"\'] class="btn .*?">(.+?)<\/a>', mu[2])
				#log("url %s" % url)
				title = u'[B](%s)[/B] [COLOR yellow][B] %s [/B][/COLOR] - [COLOR lime][%s][/COLOR]'% (time, event, league)  
				new.append((url, title))
		
		return new
	
			
	
	def resolve(self,url):		
		#log('url resolve: %s' % url)
		dialog = xbmcgui.Dialog()
		streamstemp = url[1:-1]
		#log(streamstemp)
		streams = list(streamstemp.split(','))
		#log('streams %s' % streams)
		lst = [streams[i][2:-2] for i in range(1, len(streams), 2)]
		lst = [f"Link {i+1} ({v})" for i, v in enumerate(lst)]
		#name = ['Link %s' % t for t in range(1, (len(lst)+1))]
		#lst = [('Link %s' % i)  for i in range(1, len(streams))]
		streams2 = [streams[y][2:-1] for y in range(0, len(streams), 2)]
		#log('lista %s ' % lst)
		index = dialog.select("Seleziona stream", lst)
		final = ''
		if index != -1:
			if index == 0:
				final =	streams2[index]		
			else:	
				final = streams2[index][1:]
		
		link = self.base + final
		#link = "https://stocklunch.net/embed/ywj0t0cinbr1ym" + referer
		#log(link)
		d = liveresolver.Liveresolver().resolve(link)
		#log("dopo resolved %s" % d)
		if d:
			if ".mpd" in d['url']:
				return d, False
			
			if "Referer=" in d['headers']:
				return '{}|{}'.format(d['url'], d['headers']), False
			#elif "mpd" in d['url']:
			#	return '{}|{}'.format(d['url'], d['headers']), False
			header_string = "&".join("{}={}".format(k,v) for k,v in d['headers'].items())
			return '{}|{}'.format(d['url'], header_string), False
			#return d, False
		return link, True
		
		
		 
	

