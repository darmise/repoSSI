import socket, time, threading, xbmcaddon

from requests.adapters import HTTPAdapter

from urllib3 import PoolManager
from urllib3.connection import HTTPConnection, HTTPSConnection
from urllib3.connectionpool import HTTPConnectionPool, HTTPSConnectionPool
from urllib3.util.connection import create_connection
from resources.lib.modules import doh
from resources.lib.modules.log_utils import log


DNS_TTL = 300

_addon = xbmcaddon.Addon()
_dns_cache = {}
_dns_lock = threading.Lock()


def get_dns_provider():
    try:
        value = _addon.getSetting("dns_provider")
        providers = {
            "0": "cloudflare",
            "1": "google",
            "2": "auto",
        }
        return providers.get(value, "cloudflare")
    except Exception:
        return "cloudflare"


def query_doh(host, provider):
    providers = {
        "cloudflare": ("cloudflare-dns.com", "/dns-query"),
        "google": ("dns.google", "/resolve"),
    }

    if provider == "auto":
        order = ["cloudflare", "google"]
    elif provider in providers:
        order = [provider]
    else:
        log("DNS ADAPTER - Provider non valido: %s" % provider)
        return None

    for name in order:
        server, path = providers[name]

        try:
            addresses = doh.query(
                host,
                type="A",
                server=server,
                path=path,
                fallback=False,
            )

            if addresses:
                return addresses

            #log("DNS ADAPTER - Nessuna risposta da %s per %s" % (name, host))

        except Exception as exc:
            log("DNS ADAPTER - Errore %s per %s: %s" % (name, host, exc))

    return None


def resolve_dns(host):
    try:
        socket.inet_pton(socket.AF_INET, host)
        return host
    except (OSError, AttributeError):
        pass

    if ":" in host and not host.startswith("["):
        try:
            socket.inet_pton(socket.AF_INET6, host)
            return host
        except OSError:
            pass

    
    provider = get_dns_provider()
    cache_key = (host, provider)
    now = time.time()

    with _dns_lock:
        cached = _dns_cache.get(cache_key)
        if cached and cached[0] > now:
            return cached[1]

    addresses = query_doh(host, provider)

    if not addresses:
        raise socket.gaierror(
            "Risoluzione DoH fallita per " + host
        )

    ip = addresses[0]

    if isinstance(ip, bytes):
        ip = ip.decode("ascii")

    with _dns_lock:
        _dns_cache[cache_key] = (now + DNS_TTL, ip)

    #log("DNS ADAPTER - Provider: %s, host: %s, IP: %s" % (provider, host, ip))

    return ip



class DNSHTTPConnection(HTTPConnection):
    def _new_conn(self):
        ip = resolve_dns(self.host)

        return create_connection(
            (ip, self.port),
            self.timeout,
            source_address=self.source_address,
            socket_options=self.socket_options,
        )


class DNSHTTPSConnection(HTTPSConnection):
    def _new_conn(self):
        ip = resolve_dns(self.host)

        return create_connection(
            (ip, self.port),
            self.timeout,
            source_address=self.source_address,
            socket_options=self.socket_options,
        )


class DNSHTTPConnectionPool(HTTPConnectionPool):
    ConnectionCls = DNSHTTPConnection


class DNSHTTPSConnectionPool(HTTPSConnectionPool):
    ConnectionCls = DNSHTTPSConnection



class DNSPoolManager(PoolManager):
    def __init__(
        self,
        num_pools=10,
        headers=None,
        **connection_pool_kw
    ):
        super().__init__(
            num_pools=num_pools,
            headers=headers,
            **connection_pool_kw
        )

        self.pool_classes_by_scheme = dict(
            self.pool_classes_by_scheme
        )

        self.pool_classes_by_scheme["http"] = DNSHTTPConnectionPool
        self.pool_classes_by_scheme["https"] = DNSHTTPSConnectionPool


class DNSAdapter(HTTPAdapter):
    def init_poolmanager(
        self, connections, maxsize, block=False, **kwargs
    ):
        self.poolmanager = DNSPoolManager(
            num_pools=connections,
            maxsize=maxsize,
            block=block,
            **kwargs
        )