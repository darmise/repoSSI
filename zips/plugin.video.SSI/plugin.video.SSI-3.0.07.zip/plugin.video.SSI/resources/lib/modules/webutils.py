# -*- coding: utf-8 -*-
import os, json
	
from resources.lib.modules import constants, connection, control
from resources.lib.modules.log_utils import log

#def get_ip_information():
#    ip = socket.gethostbyname(socket.gethostname())
#    return ip

def get_ip_information():
    res = connection.Connession().get_new("https://ipwho.is/", timeout=3).json()
    #log(res)
    ip = res["ip"]
    localize = res["country"]
    return ip, localize 

def updateJSON():    
    if control.setting('siti') == 'true':    
        try:
            res = connection.Connession().get_new(constants.SITES_AUTO)
            #log(res)
        except: 
            control.infoDialog("Sites update: Connection error")
        if res.status_code == 200:
            res_j = res.json()      
            saveJSON(res_j, "".join([os.path.dirname(os.path.abspath(__file__)), "\sites.json"]))
            control.infoDialog(f"Last update sites: {res_j['date']}")        
     
def initSites(name_site): 
    path = "".join([os.path.dirname(os.path.abspath(__file__)), "\sites.json"])
    if control.setting("siti") == "true":
        #json_sites = requests.get(constants.SITES_AUTO).json()
        json_sites = accessJSON(path)
        json_list = json_sites['sites']
        for site in json_list:
            if site['name'] == name_site:
                url = site['url']    
    else: url = control.setting(name_site)	
    return url

def getStatus(name_site): 
    path = "".join([os.path.dirname(os.path.abspath(__file__)), "\sites.json"])
    json_sites = accessJSON(path)
    json_list = json_sites['sites']
    for site in json_list:
        if name_site in site['name']:
            status = site['status']    	
    return status

def accessJSON(name):
	with open(name, 'r') as file:
		return json.load(file)
	
def saveJSON(lista, name):
    with open(name, "w") as out:
	    json.dump(lista, out)
		
def clearJSON():
	em = []
	saveJSON(em, os.path.join(os.path.dirname(__file__), 'liveresolver\json_data.json'))
	control.infoDialog("JSON pulito!")       