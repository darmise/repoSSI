import requests

from resources.lib.modules.dns_adapter import DNSAdapter


class Connession:
    _session = None

    def __init__(self):
        if Connession._session is None:
            Connession._session = self._create_session()

    @staticmethod
    def _create_session():
        session = requests.Session()

        adapter = DNSAdapter()
        session.mount("http://", adapter)
        session.mount("https://", adapter)

        return session
    
    @property
    def session(self):
        return Connession._session

    def get(self, url, **kwargs):
        return self.session.get(url, **kwargs)

    def post(self, url, **kwargs):
        return self.session.post(url, **kwargs)
    
    def get_new(self, url, **kwargs):
        with self._create_session() as session:
            return session.get(url, **kwargs)

    def put_new(self, url, **kwargs):
        with self._create_session() as session:
            return session.put(url, **kwargs)