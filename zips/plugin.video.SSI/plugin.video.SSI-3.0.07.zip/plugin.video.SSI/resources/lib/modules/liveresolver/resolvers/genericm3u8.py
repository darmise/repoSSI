import re, json, base64, math, ast, time, operator

from urllib.parse import urlparse, unquote, parse_qs
from resources.lib.modules.log_utils import log
from resources.lib.modules import constants, connection, control

class Resolver():
    
    M3U8_RE = re.compile('["\']((?:https?:\/\/|https?:\\\/\\\/)[^"\']+\.m3u8[^"\']*)["\']')
    ECONFIG_RE = re.compile("econfig\s*=\s*['\"](.+?)['\"]")
    STREAMURL_RE = re.compile('streamurl[\s\S]*?(https?[^"\']+\.m3u8)')
    DAMITV = re.compile('fetch\([\'"](.+?)[\'"]\s*\+.*?[\'"](\?t=)')
    DAMI_SESSION = re.compile('fetch\([\'"](.+?)[\'"]')
    #ENDPOINT = re.compile('point:\s*[\'\"](.+?)[\'\"]')
    #SITE = re.compile('action\s*=\s*[\'\"](.+?)[\'\"]')

    ARRAY_OBF = re.compile(
        r'\bvar\s+'
        r'(?P<array_name>_\w+)\s*=\s*(?P<array>\[[\d,\s]+\])\s*,\s*'
        r'(?P<key1_name>_\w+)\s*=\s*(?P<key1>\d+)\s*,\s*'
        r'(?P<key2_name>_\w+)\s*=\s*(?P<key2>\d+)'
        r'.*?'
        r'\(\('
        r'(?P=array_name)\[[^\]]+\]\s*\^\s*(?P=key1_name)'
        r'\)\s*-\s*(?P=key2_name)'
        r'\s*\+\s*(?P<add>\d+)'
        r'\)\s*(?P<oper>\W)\s*(?P<mask>\d+)',
        re.DOTALL
    )
    TVNOW = re.compile('''href=[\"']([^"\s>]*(?:channels|streamService)[^"\s>]*\.js)''')
    
    CK = re.compile('var _[ck] =\s*[\'"](.+)[\'"]')
    
    
    HEADERS = {
            "User-Agent": constants.USER_AGENT
    }
    
    def __init__(self):
        pass
  
    def hex_to_bytes(self, h):
        b = bytearray(len(h) // 2)

        for i in range(0, len(h), 2):
            b[i // 2] = int(h[i:i + 2], 16)

        return b

    def xor_decrypt(self, ch, kh):
        c = self.hex_to_bytes(ch)
        k = self.hex_to_bytes(kh)

        s = ''
        for i in range(len(c)):
            s += chr(c[i] ^ k[i % len(k)])

        return s  
  
    def decode_econfig(self, input_data):
        if not input_data:
            return None

        order = [2, 0, 3, 1]
        parts_count = 4

        data = base64.b64decode(input_data).decode("utf-8", errors="ignore")
        length = len(data)
        part_size = math.floor(length / parts_count)

        parts = []
        offset = 0

        for _ in range(parts_count):
            parts.append(data[offset:offset + part_size])
            offset += part_size

        decoded_parts = [None] * len(order)

        for i in range(len(order)):
            p = parts[i]
            p = p[:3] + p[4:]
            decoded_parts[order[i]] = base64.b64decode(p).decode("utf-8", errors="ignore")

        merged = "".join(decoded_parts)
        final = base64.b64decode(merged).decode("utf-8", errors="ignore")
        return json.loads(final)
    
    def clear_play_url(self, play):
        
        play_url = play.replace("\\", "").strip()
        play_url = play_url.replace("u0026e=", "&e=")
             
        if play_url.startswith("%3C"):
            return None
                
        if play_url.startswith("//"):
            play_url = "https:" + play_url
                
        if not urlparse(play_url).scheme:
            play_url = "https://" + play_url.replace("://", "")
                
        return play_url   

    def build_headers(self, url):
        host = urlparse(url)
        return {
            "Referer": f"{host.scheme}://{host.netloc}/",
            "Origin": f"{host.scheme}://{host.netloc}",
            "User-Agent": constants.USER_AGENT
        }
    
    def resolve(self, url, html='', referer = None):
        s = connection.Connession()
        s.session.headers.update(self.HEADERS)   
        
        if "matchora" in url and bool(re.search(r'\d+$', url)):
            ch = url.split("/")[-1]
            url_parse =  urlparse(url) 
            res_json = s.get_new(f"{url_parse.scheme}://{url_parse.netloc}/api/play/{ch}", headers={"User-Agent": constants.USER_AGENT}) 
            
            if res_json.status_code == 200:
                res = res_json.json() 
                
                if res["ready"]:
                    play_url = res["url"]    
                else: 
                    control.infoDialog("Flusso non disponibile")
                    return {'url': ""} 
            return {'url': play_url, 'headers': self.build_headers(url)}
        
        if '.m3u8' in url and "&url=" not in url:
            if "link=" in url:
                url = unquote(url.split("link=")[1])
                return {'url': url, 'headers': {"User-Agent": constants.USER_AGENT}}
            if referer:
                return {'url': url, 'headers': self.build_headers(referer)}
            return {'url': url, 'headers': self.build_headers(url)}
        
        if referer:
            s.session.headers["Referer"] = referer
        log(referer)
        try:
            resp = s.get(url, allow_redirects=True)
            #if resp.status_code == 429:
            #    resp = s.get(url)
            
            html = resp.text
            log(html)
        
        except Exception as e:
            log(e)
            return None
        
        url = resp.url
        
        # ----------- ARRAY_OBF ----------------
        match = self.ARRAY_OBF.search(html, re.DOTALL)     
        if match:
            array = ast.literal_eval(match.group("array"))
            op = {"%": operator.mod, "&": operator.and_}[match.group("oper").strip()]
            decoded = ''.join(chr(op((val ^ int(match.group("key1"))) - int(match.group("key2")) + int(match.group("add")), int(match.group("mask")))) 
                        for val in array)
            play_url = re.search("(?:url|URL)\s*=\s*[\"'](.+?)[\"']", decoded).group(1)
            play_url = self.clear_play_url(play_url)
            return {'url': play_url, 'headers': self.build_headers(url)}
        
        #----------   CK ---------------
        ck = self.CK.findall(html)
        if ck:
            stream_url = self.xor_decrypt(ck[0], ck[1])
            return {'url': stream_url, 'headers': {"User-Agent": constants.USER_AGENT}}

        # ----------- TV NOW -------------
        tvnow = self.TVNOW.findall(html)
        if tvnow:
            id = url.split("/embed/")[1].rstrip("/")
            domain = urlparse(url)
            base = f"{domain.scheme}://{domain.netloc}"
            h1 = s.get(f"{base}{tvnow[1]}", headers=self.build_headers(url)).text
            pattern = rf'\{{[^}}]*?channel_id:\s*["\']([^"\']+)["\'][^}}]*?slug:\s*["\']{re.escape(id)}["\'][^}}]*?\}}'
            ch_id = re.search(pattern, h1, re.DOTALL).group(1)
            h2 = s.get(f"{base}{tvnow[0]}", headers=self.build_headers(url)).text
            domain2 = re.search('''["']([^"']*api[^"']*)["']''', h2).group(1) 
            stream = s.get(f"{domain2}{ch_id}", headers=self.build_headers(url)).json()["m3u8"]
            return {'url': stream, 'headers': {"User-Agent": constants.USER_AGENT}}
            
        #---------- DAMITV -----------------
        dami = self.DAMITV.search(html)
        if dami:
            head = {"Referer": url}
            session = self.DAMI_SESSION.findall(html)
            domain = urlparse(url)
            
            sid = s.get(f"{domain.scheme}://{domain.netloc}{session[0]}", headers=head).json()["s"]
            
            time.sleep(2.5)
            
            t = s.get(f"{domain.scheme}://{domain.netloc}{session[1]}{sid}", headers=head).json()["t"]
            
            if "resolve" in domain.query:
                param = parse_qs(domain.query)["resolve"][0]
                stream = s.get(f"{domain.scheme}://{domain.netloc}{session[3]}{param}?t=", headers=head).json()["stream"]
            
            else:
                stream = unquote(parse_qs(domain.query)["url"][0])
                
                if "tk=" not in domain.query or "e=" not in domain.query:
                    r = s.get(f"{domain.scheme}://{domain.netloc}{session[2]}", headers=head).json()
                    tk, e = r["tk"], r["e"]
                    stream = f"{stream}?tk={tk}&e={e}"
            
            if "&t=" not in stream:
                stream = f"{stream}&t={t}"
            
            return {'url': stream, 'headers': self.build_headers(url)}
        # --------------------------------
        
        #ch = self.ENDPOINT.search(html)
        #if ch:
        #    token = s.post(f"{ch.group(1)}challenge", headers=self.HEADERS).json()
        #    log(token)
        #    log(token["token"])
        #    return
        #    token2 = s.post(f"{ch.group(1)}redeem", headers= self.HEADERS, json={"token": token.strip()}).json()
        #    log(token2)
        #    site = self.SITE.search(html)
        #    log(site)
        #    html = s.post(f"{url}{site}", headers=self.HEADERS, json={"token": token2}).text
        #    log(html)
        #return
        		
        m = self.ECONFIG_RE.search(html)
        if m:
            cfg = self.decode_econfig(m.group(1))
            
            if cfg and "stream_url" in cfg:
                return {'url': cfg["stream_url"], 'headers': self.build_headers(url)}	

        m = self.M3U8_RE.search(html)
        
        if not m:
            return None
        
        play_url = m.group(1)
        
        play_url = self.clear_play_url(play_url)
        
        if len(play_url) > 60 and "streamurl" in play_url:
            m2 = self.STREAMURL_RE.search(html)
            if m2:
                play_url = m2.group(1)
        
        if "daddy" in url:
            t = int(time.time() * 1000)
            play_url = f"{play_url}?_={t}"
        
        #t = s.get(play_url, headers=self.build_headers(url)).text
        #log(t)              
        return {'url': play_url, 'headers': self.build_headers(url)}

